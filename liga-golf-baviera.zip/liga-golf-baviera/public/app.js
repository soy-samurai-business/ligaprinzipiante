// Liga de Golf Baviera — cliente web (SPA sin dependencias)

const app = document.getElementById('app');
const S = { me: null, hasPhoto: false, settings: {}, cart: loadCart(), liveHole: {}, tab: {}, shopSel: {}, adminRound: null, adminPlayer: null,
  live: null, liveAny: false, reg: { step: 1, data: {}, photo: null, errors: {} }, lastReg: null, photoV: Date.now() };
const ACT = {};
const FORM = {};
const CHANGE = {};
let current = { live: false };

const SHIRT_SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL'];

// ---------- Utilidades ----------

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const euros = (c) => (c / 100).toLocaleString('es-ES', { style: 'currency', currency: 'EUR' });
const initials = (n) => String(n || '?').split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
const fmtDate = (d, opts = { weekday: 'short', day: 'numeric', month: 'short' }) => new Date(`${String(d).slice(0, 10)}T12:00:00`).toLocaleDateString('es-ES', opts);
const fmtLong = (d) => fmtDate(d, { weekday: 'long', day: 'numeric', month: 'long' });
const fmtDateTime = (d) => (d ? new Date(d).toLocaleString('es-ES', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '');
const nineLabel = (n) => (n === 'back' ? 'Hoyos 10–18' : 'Hoyos 1–9');
const STATUS = { scheduled: ['Programada', ''], live: ['En juego', 'live'], closed: ['Jugada', 'closed'] };
const statusBadge = (s) => `<span class="badge ${STATUS[s][1]}">${s === 'live' ? '<span class="livedot"></span>' : ''}${STATUS[s][0]}</span>`;
const PSTATUS = { pending: ['Pendiente de contraseña', 'amber'], active: ['Activo', ''], disabled: ['Baja', 'closed'] };
const hcp = (h) => (h < 0 ? `+${Math.abs(h)}` : String(h).replace('.', ','));
const toPar = (n) => (n === 0 ? 'E' : n > 0 ? `+${n}` : String(n));
const ptsCls = (p) => (p === 0 ? 'zero' : p >= 3 ? 'high' : '');
const dots = (n) => (n > 0 ? '●'.repeat(n) : n < 0 ? '−'.repeat(-n) : '');
const isAdmin = () => S.me?.role === 'admin';
const feature = (k) => !!S.settings[`feature_${k}`];
const canSee = (k) => feature(k) || isAdmin();
const ageOf = (birth) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(birth || '')) return null;
  const b = new Date(`${birth}T12:00:00`), t = new Date();
  let a = t.getFullYear() - b.getFullYear();
  if (t.getMonth() < b.getMonth() || (t.getMonth() === b.getMonth() && t.getDate() < b.getDate())) a--;
  return a;
};
const photoUrl = (id) => `/api/photos/${id}?v=${S.photoV}`;
const avatar = (id, name, has, cls = '') => (has
  ? `<img class="avatar ${cls}" src="${photoUrl(id)}" alt="" loading="lazy">`
  : `<span class="avatar ${cls}">${esc(initials(name))}</span>`);

async function api(path, { method = 'GET', body } = {}) {
  const r = await fetch(`/api${path}`, { method, credentials: 'same-origin',
    headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(d.error || 'Algo ha fallado'); e.fields = d.fields; e.status = r.status; throw e; }
  return d;
}

let toastTimer;
function toast(msg, error = false) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = `show${error ? ' error' : ''}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.className = ''; }, 3200);
}

function loadCart() { try { return JSON.parse(localStorage.getItem('cart') || '[]'); } catch { return []; } }
function saveCart() { try { localStorage.setItem('cart', JSON.stringify(S.cart)); } catch { /* sin almacenamiento */ } }

function scoreCls(strokes, par) {
  if (!strokes) return '';
  const d = strokes - par;
  return d <= -2 ? 'eagle' : d === -1 ? 'birdie' : d === 1 ? 'bogey' : d >= 2 ? 'double' : '';
}

function tabs(key, items, def) {
  const cur = items.some(([id]) => id === S.tab[key]) ? S.tab[key] : def;
  return { cur, html: `<div class="tabs" role="tablist">${items.map(([id, label]) =>
    `<button role="tab" class="${id === cur ? 'active' : ''}" aria-selected="${id === cur}" data-act="tab" data-key="${key}" data-id="${id}">${label}</button>`).join('')}</div>` };
}
ACT.tab = (el) => { S.tab[el.dataset.key] = el.dataset.id; render(true); };
ACT.go = (el) => { location.hash = el.dataset.href.slice(1); };

// Reduce la foto en el navegador (máx. 1024 px, JPEG) antes de enviarla: subidas rápidas desde el móvil.
async function resizePhoto(file) {
  if (!file || !file.type.startsWith('image/')) throw new Error('El archivo no es una imagen');
  let src;
  try { src = await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch {
    src = await new Promise((res, rej) => { const img = new Image(); img.onload = () => res(img); img.onerror = () => rej(new Error('No se pudo leer la imagen')); img.src = URL.createObjectURL(file); });
  }
  const w = src.width, h = src.height;
  const scale = Math.min(1, 1024 / Math.max(w, h));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(w * scale); canvas.height = Math.round(h * scale);
  canvas.getContext('2d').drawImage(src, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/jpeg', 0.85);
}

function showFieldErrors(root, fields = {}) {
  root.querySelectorAll('[data-err]').forEach((el) => { el.textContent = fields[el.dataset.err] || ''; });
  root.querySelectorAll('[name]').forEach((el) => { if (fields[el.name]) el.setAttribute('aria-invalid', 'true'); else el.removeAttribute('aria-invalid'); });
  root.querySelectorAll('[data-errbox]').forEach((el) => el.classList.toggle('err', !!fields[el.dataset.errbox]));
  const first = root.querySelector('[aria-invalid="true"], .err:not(:empty)');
  first?.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

const field = (name, label, input, { full = false, hint = '', opt = false } = {}) => `
  <div class="field ${full ? 'full' : ''}"><label for="f-${name}">${label}${opt ? ' <span class="opt">(opcional)</span>' : ''}</label>${input}
    ${hint ? `<span class="hint">${hint}</span>` : ''}<span class="err" data-err="${name}"></span></div>`;

// ---------- Navegación ----------

const ICONS = {
  home: '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  live: '<circle cx="12" cy="12" r="3"/><path d="M5.6 5.6a9 9 0 0 0 0 12.8M18.4 5.6a9 9 0 0 1 0 12.8M8.5 8.5a5 5 0 0 0 0 7M15.5 8.5a5 5 0 0 1 0 7"/>',
  table: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  cal: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  shop: '<path d="M8 3l-5 4 3 3 2-1v12h8V9l2 1 3-3-5-4c-1 1.5-2.3 2-4 2S9 4.5 8 3z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c1-3.5 3.5-5 6.5-5s5.5 1.5 6.5 5M16 4.5a3.5 3.5 0 0 1 0 7M18 15c2 .7 3.3 2.3 4 5"/>',
  pen: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M14 6l4 4"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3"/>',
  flag: '<path d="M6 21V4M6 4l11 4-11 4"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
};
const icon = (k) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[k]}</svg>`;

function navItems() {
  if (!S.me) return [['/', 'Inicio', 'home'], ['/registro', 'Inscríbete', 'pen', 'cta'], ['/entrar', 'Entrar', 'key']];
  const items = [['/', 'Inicio', 'home'], ['/clasificacion', 'Clasificación', 'table'], ['/jornadas', 'Jornadas', 'cal'], ['/jugadores', 'Jugadores', 'users']];
  if (canSee('live')) items.push(['/live', 'Live', 'live', feature('live') ? '' : 'draft']);
  if (canSee('shop')) items.push(['/tienda', 'Tienda', 'shop', feature('shop') ? '' : 'draft']);
  items.push(['/perfil', 'Mi ficha', 'user']);
  return items;
}

function renderChrome(path) {
  const active = (p) => (p === '/' ? path === '/' : path.startsWith(p) || (p === '/jornadas' && /^\/(jornada|tarjeta)/.test(path)) || (p === '/jugadores' && path.startsWith('/jugador')));
  const items = navItems();
  document.getElementById('mainnav').innerHTML = [...items, ...(isAdmin() ? [['/admin', 'Comité']] : [])]
    .map(([p, l, , f]) => `<a href="#${p}" class="${active(p) ? 'active' : ''}">${p === '/live' && S.liveAny && feature('live') ? '<span class="livedot"></span>' : ''}${l}${f === 'draft' ? '<span class="draft">borrador</span>' : ''}</a>`).join('');
  const mobile = items.filter(([p]) => !(S.me && ['/live', '/tienda'].includes(p) && !feature(p.slice(1))));
  document.getElementById('tabbar').innerHTML = mobile.slice(0, 5).map(([p, l, i, f]) =>
    `<a href="#${p}" class="${active(p) ? 'active' : ''} ${f === 'cta' ? 'cta' : ''}">${icon(i)}${l === 'Clasificación' ? 'Clasif.' : l}</a>`).join('');
  const chip = document.getElementById('userchip');
  chip.innerHTML = S.me ? avatar(S.me.id, S.me.name, S.hasPhoto) : '<span class="btn small">Entrar</span>';
  chip.href = S.me ? (isAdmin() ? '#/admin' : '#/perfil') : '#/entrar';
  chip.setAttribute('aria-label', S.me ? 'Mi ficha' : 'Entrar');
  document.getElementById('brand-name').textContent = S.settings.league_name || 'Liga de Golf';
  document.getElementById('brand-season').textContent = `${S.settings.course_name || ''} · ${S.settings.season || ''}`;
}

const routes = [
  [/^\/$/, viewHome], [/^\/registro$/, viewRegister], [/^\/gracias$/, viewThanks], [/^\/privacidad$/, viewPrivacy],
  [/^\/clave\/([A-Za-z0-9_-]+)$/, viewSetPassword], [/^\/recuperar$/, viewForgot], [/^\/entrar$/, viewLogin],
  [/^\/clasificacion$/, viewStandings], [/^\/jornadas$/, viewRounds], [/^\/jornada\/(\d+)$/, viewRound], [/^\/tarjeta\/(\d+)$/, viewCard],
  [/^\/jugadores$/, viewPlayers], [/^\/jugador\/(\d+)$/, viewPlayer], [/^\/perfil$/, viewProfile],
  [/^\/live$/, viewLive], [/^\/tienda$/, viewShop], [/^\/admin$/, viewAdmin],
];

let renderSeq = 0;
async function render(keepScroll = false) {
  const path = location.hash.slice(1) || '/';
  const seq = ++renderSeq;
  const y = window.scrollY;
  renderChrome(path);
  const [re, view] = routes.find(([r]) => r.test(path)) || [/$/, viewNotFound];
  const params = path.match(re).slice(1);
  try {
    const out = await view(...params);
    if (seq !== renderSeq) return;
    app.innerHTML = out.html;
    current = { live: !!out.live, path };
    out.mount?.();
    window.scrollTo(0, keepScroll ? y : 0);
  } catch (e) {
    if (seq !== renderSeq) return;
    if (e.status === 401) { app.innerHTML = loginPrompt(); return; }
    app.innerHTML = `<div class="card empty"><h2>No se ha podido cargar</h2><p>${esc(e.message)}</p><a class="btn" href="#/">Volver al inicio</a></div>`;
  }
  renderChrome(path);
}

function viewNotFound() { return { html: '<div class="card empty"><h2>Página no encontrada</h2><a class="btn" href="#/">Ir al inicio</a></div>' }; }

function loginPrompt(msg = 'Esta sección es para jugadores inscritos.') {
  return `<div class="card empty form-narrow"><h2>Entra en tu cuenta</h2><p>${esc(msg)}</p>
    <div class="row" style="justify-content:center"><a class="btn" href="#/entrar">Entrar</a><a class="btn secondary" href="#/registro">Inscribirme</a></div></div>`;
}
const needLogin = () => { if (!S.me) { const e = new Error('login'); e.status = 401; throw e; } };

// ---------- Inicio ----------

async function viewHome() {
  const { rounds } = await api('/rounds');
  const next = rounds.find((r) => r.status === 'scheduled');
  if (!S.me) return homePublic(rounds, next);
  const [st] = await Promise.all([api('/standings')]);
  const mine = st.rows.find((r) => r.user_id === S.me.id);
  const upcoming = rounds.filter((r) => r.status === 'scheduled').slice(0, 3);
  return { live: true, html: `
    <section class="hero">
      <div class="eyebrow">Temporada ${esc(S.settings.season)} · ${esc(S.settings.course_name)}</div>
      <h1>¡Hola, ${esc(S.me.first_name || S.me.name)}!</h1>
      <p class="lead">${mine ? `Vas <b>${mine.pos}º</b> en la clasificación general con <b>${mine.total} puntos</b>.` : 'Apúntate a las próximas jornadas para empezar a puntuar.'}</p>
      <div class="row"><a class="btn" href="#/perfil">Mi ficha</a><a class="btn secondary" href="#/clasificacion">Clasificación</a></div>
    </section>
    <div class="grid grid-2" style="margin-top:16px">
      <div class="card"><h2>Próximas jornadas</h2>
        ${upcoming.length ? upcoming.map((r) => `<div class="spread" style="padding:12px 0;border-top:1px solid var(--line)">
          <div><b>Jornada ${r.number}</b> · ${esc(fmtLong(r.date))}<br><span class="small muted">${nineLabel(r.nine)} · primera salida ${esc(r.first_tee)} · ${r.entries} inscritos</span></div>
          ${entryButton(r, true)}</div>`).join('') : '<p class="empty">No hay jornadas programadas.</p>'}
        <a href="#/jornadas" class="small">Ver todas las jornadas →</a>
      </div>
      <div class="card">
        <div class="spread"><h2>Clasificación general</h2><a href="#/clasificacion" class="small">Completa →</a></div>
        ${st.rows.length ? standingsMini(st.rows.slice(0, 8)) : '<p class="empty">Todavía no hay tarjetas validadas.</p>'}
      </div>
    </div>` };
}

function homePublic(rounds, next) {
  const f = (ico, t, d) => `<div class="feature"><span class="ico">${icon(ico)}</span><div><b>${t}</b><p class="small muted" style="margin:2px 0 0">${d}</p></div></div>`;
  return { html: `
    <section class="hero">
      <div class="eyebrow">Inscripciones abiertas · Temporada ${esc(S.settings.season)}</div>
      <h1>${esc(S.settings.league_name)}</h1>
      <p class="lead">10 jornadas a 9 hoyos en ${esc(S.settings.course_name)}. Inscríbete, consulta tus puntuaciones y apúntate a cada jornada desde el móvil.</p>
      <div class="row"><a class="btn lg" href="#/registro">Inscríbete en la liga</a><a class="btn secondary lg" href="#/entrar">Ya tengo cuenta</a></div>
    </section>
    <div class="grid grid-3" style="margin-top:16px">
      <div class="card flat">${f('flag', '10 jornadas · 9 hoyos', `Todas en ${esc(S.settings.course_name)}, con salidas asignadas por el comité.`)}</div>
      <div class="card flat">${f('table', `Cuentan tus ${S.settings.best_cards} mejores tarjetas`, 'Modalidad Stableford neto. Clasificación por jornada y general.')}</div>
      <div class="card flat">${f('user', 'Tu ficha online', 'Tus datos, tus puntuaciones y la inscripción a las jornadas en un solo sitio.')}</div>
    </div>
    <div class="card" style="margin-top:16px">
      <div class="spread"><h2>Calendario</h2>${next ? `<span class="badge">Próxima: ${esc(fmtDate(next.date))}</span>` : ''}</div>
      <div class="tablewrap"><table><thead><tr><th>Jornada</th><th>Fecha</th><th>Recorrido</th><th></th></tr></thead><tbody>
        ${rounds.map((r) => `<tr><td><b>J${r.number}</b></td><td>${esc(fmtLong(r.date))}</td><td>${nineLabel(r.nine)}</td><td class="r">${statusBadge(r.status)}</td></tr>`).join('')}
      </tbody></table></div>
    </div>
    <p class="small muted" style="text-align:center;margin-top:20px"><a href="#/privacidad">Política de privacidad</a></p>` };
}

function standingsMini(rows) {
  return `<table><thead><tr><th>Pos</th><th>Jugador</th><th class="c">Jug.</th><th class="r">Pts</th></tr></thead><tbody>
    ${rows.map((r) => `<tr class="link ${r.user_id === S.me?.id ? 'me' : ''}" data-act="go" data-href="#/jugador/${r.user_id}">
      <td class="pos">${r.pos}</td><td>${esc(r.name)}</td><td class="c">${r.played}</td><td class="r total">${r.total}</td></tr>`).join('')}</tbody></table>`;
}

function entryButton(r, compact = false) {
  if (r.status !== 'scheduled') return '';
  if (r.groups) return `<a class="btn secondary small" href="#/jornada/${r.id}">Ver horarios</a>`;
  if (!S.me) return '<a class="btn small" href="#/entrar">Entra para apuntarte</a>';
  if (isAdmin()) return `<a class="btn secondary small" href="#/jornada/${r.id}">Ver</a>`;
  return r.entered
    ? `<div class="row"><span class="badge">✓ Inscrito</span><button class="btn secondary small" data-act="entry" data-id="${r.id}" data-on="0">Borrarme</button></div>`
    : `<button class="btn ${compact ? 'small' : ''}" data-act="entry" data-id="${r.id}" data-on="1">Apuntarme</button>`;
}
ACT.entry = async (el) => {
  try { await api(`/rounds/${el.dataset.id}/entry`, { method: 'POST', body: { on: el.dataset.on === '1' } });
    toast(el.dataset.on === '1' ? 'Te has apuntado a la jornada' : 'Inscripción anulada'); render(true); } catch (e) { toast(e.message, true); }
};

// ---------- Inscripción de jugadores ----------

function viewRegister() {
  if (S.me) return { html: `<div class="card empty form-narrow"><h2>Ya estás inscrito</h2><p>Has entrado como ${esc(S.me.name)}.</p><a class="btn" href="#/perfil">Ir a mi ficha</a></div>` };
  const R = S.reg;
  const steps = `<div class="steps"><span class="${R.step === 1 ? 'on' : 'done'}"><b>${R.step > 1 ? '✓' : '1'}</b>Tus datos</span><span class="${R.step === 2 ? 'on' : ''}"><b>2</b>Privacidad y consentimientos</span></div>`;
  const head = `<div class="pagehead"><div class="eyebrow">Temporada ${esc(S.settings.season)}</div><h1>Inscripción en la liga</h1>
    <p>Rellena tus datos de golfista. Al terminar recibirás un correo para crear tu contraseña de acceso.</p></div>`;
  return { html: `<div class="form-mid">${head}<div class="card">${steps}${R.step === 1 ? regStep1(R) : regStep2(R)}</div></div>`,
    mount: () => showFieldErrors(app, R.errors) };
}

function regStep1(R) {
  const v = (k) => esc(R.data[k] ?? '');
  const maxBirth = new Date(Date.now() - 4 * 365.25 * 864e5).toISOString().slice(0, 10);
  return `<form data-form="reg1" novalidate>
    <div class="fgrid">
      ${field('first_name', 'Nombre', `<input id="f-first_name" name="first_name" value="${v('first_name')}" autocomplete="given-name" required>`)}
      ${field('last_name', 'Apellidos', `<input id="f-last_name" name="last_name" value="${v('last_name')}" autocomplete="family-name" required>`)}
      ${field('email', 'Correo electrónico', `<input id="f-email" name="email" type="email" value="${v('email')}" autocomplete="email" inputmode="email" required>`, { hint: 'Aquí recibirás el enlace para crear tu contraseña.' })}
      ${field('phone', 'Teléfono', `<input id="f-phone" name="phone" type="tel" value="${v('phone')}" autocomplete="tel" inputmode="tel" required>`)}
      ${field('birth_date', 'Fecha de nacimiento', `<input id="f-birth_date" name="birth_date" type="date" value="${v('birth_date')}" max="${maxBirth}" min="1920-01-01" autocomplete="bday" required>`)}
      ${field('licence', 'Número de licencia', `<input id="f-licence" name="licence" value="${v('licence')}" autocapitalize="characters" placeholder="Ej.: AM12345678" required>`, { hint: 'Licencia federativa (RFEG).' })}
      ${field('handicap', 'Hándicap', `<input id="f-handicap" name="handicap" value="${v('handicap')}" inputmode="decimal" placeholder="Ej.: 18,4" required>`, { hint: 'Tu hándicap actual. Después lo actualiza el comité.' })}
      ${field('shirt_size', 'Talla de polo', `<select id="f-shirt_size" name="shirt_size" required><option value="">Elige talla</option>${SHIRT_SIZES.map((s) => `<option ${R.data.shirt_size === s ? 'selected' : ''}>${s}</option>`).join('')}</select>`)}
      ${field('instagram', 'Cuenta de Instagram', `<input id="f-instagram" name="instagram" value="${v('instagram')}" placeholder="@tuusuario" autocapitalize="none" autocorrect="off">`, { full: true, opt: true })}
      <div class="field full"><label>Fotografía</label>
        <div class="photo-pick" data-errbox="photo">
          ${R.photo ? `<img class="avatar" src="${R.photo}" alt="Tu foto">` : `<span class="avatar">${icon('user')}</span>`}
          <div><label class="btn soft small" for="f-photo" style="cursor:pointer">${R.photo ? 'Cambiar foto' : 'Añadir foto'}</label>
            <input id="f-photo" type="file" accept="image/*" class="hidden" data-act-change="regphoto">
            <p class="small muted" style="margin:6px 0 0">Una foto reciente en la que se te vea bien la cara. Se usará en tu ficha de jugador.</p></div>
        </div><span class="err" data-err="photo"></span></div>
    </div>
    <input name="website" tabindex="-1" autocomplete="off" class="hidden" aria-hidden="true">
    <button class="btn block lg" style="margin-top:8px">Continuar</button>
  </form>`;
}

CHANGE.regphoto = async (el) => {
  const file = el.files[0];
  if (!file) return;
  try { S.reg.photo = await resizePhoto(file); S.reg.errors.photo = ''; saveStep1Values(); render(true); } catch (e) { toast(e.message, true); }
};

function saveStep1Values() {
  const form = app.querySelector('form[data-form="reg1"]');
  if (form) Object.assign(S.reg.data, Object.fromEntries(new FormData(form)));
}

FORM.reg1 = (fd, form) => {
  const d = Object.fromEntries(fd);
  if (d.website) return;
  Object.assign(S.reg.data, d);
  const err = {};
  const req = { first_name: 'Escribe tu nombre', last_name: 'Escribe tus apellidos', email: 'Escribe tu correo', phone: 'Escribe tu teléfono',
    birth_date: 'Indica tu fecha de nacimiento', licence: 'Indica tu número de licencia', handicap: 'Indica tu hándicap', shirt_size: 'Elige una talla' };
  for (const [k, m] of Object.entries(req)) if (!String(d[k] || '').trim()) err[k] = m;
  if (d.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(d.email.trim())) err.email = 'Email no válido';
  const h = Number(String(d.handicap).replace(',', '.'));
  if (d.handicap && (!Number.isFinite(h) || h < -10 || h > 54)) err.handicap = 'Hándicap entre -10 y 54';
  if (!S.reg.photo) err.photo = 'Añade una fotografía';
  S.reg.errors = err;
  if (Object.keys(err).length) { showFieldErrors(form, err); return; }
  S.reg.step = 2;
  render();
};

function legalEntity() {
  const s = S.settings;
  const miss = (v, label) => (v ? esc(v) : `<span class="pending-legal">[${label}: completar en Comité → Ajustes]</span>`);
  return { name: miss(s.legal_name, 'razón social'), cif: miss(s.legal_cif, 'CIF'), address: miss(s.legal_address, 'dirección'), email: miss(s.legal_email, 'email de contacto') };
}

function regStep2(R) {
  const L = legalEntity();
  const minor = (ageOf(R.data.birth_date) ?? 99) < 14;
  const c = (name, req, title, text) => `<label class="consent ${req ? 'req' : ''}" data-errbox="${name}">
    <input type="checkbox" name="${name}" ${R.data[name] ? 'checked' : ''}><span><b>${title}${req ? '' : ' <span class="small muted" style="font-weight:400">(opcional)</span>'}</b>
    <span class="small muted">${text}</span><span class="err" data-err="${name}"></span></span></label>`;
  return `<form data-form="reg2" novalidate>
    <h2>Información básica sobre protección de datos</h2>
    <div class="infobox"><dl>
      <dt>Responsable</dt><dd>${L.name} (${L.cif})</dd>
      <dt>Finalidad</dt><dd>Gestionar tu inscripción y participación en la liga: fichas, horarios, clasificaciones y comunicaciones necesarias. Con tu permiso, enviarte novedades y publicar tu imagen.</dd>
      <dt>Legitimación</dt><dd>Tu inscripción en la liga y, para lo opcional, tu consentimiento.</dd>
      <dt>Destinatarios</dt><dd>No se ceden datos a terceros salvo obligación legal. Proveedor de alojamiento en la UE.</dd>
      <dt>Derechos</dt><dd>Acceso, rectificación, supresión, oposición, limitación y portabilidad, escribiendo a ${L.email}.</dd>
      <dt>Más información</dt><dd><a href="#/privacidad" target="_blank" rel="noopener">Política de privacidad completa</a></dd>
    </dl></div>
    <div style="margin-top:16px">
      ${c('consent_privacy', true, 'He leído y acepto la política de privacidad', 'Necesario para inscribirte: tratamiento de tus datos para gestionar tu participación en la liga.')}
      ${c('consent_notifications', false, 'Quiero recibir notificaciones de la liga', 'Convocatorias, avisos y novedades por correo electrónico, SMS o WhatsApp. Los correos imprescindibles (acceso a tu cuenta, horarios de tus jornadas) los recibirás igualmente.')}
      ${c('consent_image', false, 'Autorizo la publicación de mi imagen', 'Fotografías y vídeos tomados durante las jornadas y la foto de mi ficha, en la web y en las redes sociales de la liga (Instagram, Facebook…), pudiendo mencionar mi cuenta de Instagram.')}
    </div>
    ${minor ? `<div class="notice amber" style="margin-top:16px"><b>Jugador menor de 14 años.</b> La inscripción la debe autorizar su padre, madre o tutor legal.</div>
      <div class="fgrid" style="margin-top:12px">
        ${field('guardian_name', 'Nombre del padre, madre o tutor', `<input id="f-guardian_name" name="guardian_name" value="${esc(R.data.guardian_name || '')}" required>`)}
        ${field('guardian_email', 'Email del tutor', `<input id="f-guardian_email" name="guardian_email" type="email" value="${esc(R.data.guardian_email || '')}" required>`)}
      </div>
      ${c('consent_guardian', true, 'Soy su padre, madre o tutor legal y autorizo la inscripción', 'Y los consentimientos marcados arriba en nombre del menor.')}` : ''}
    <p class="small muted" style="margin-top:14px">Puedes cambiar los consentimientos opcionales cuando quieras desde tu ficha.</p>
    <div class="row" style="margin-top:8px"><button type="button" class="btn secondary" data-act="regback">← Volver</button><button class="btn lg" style="flex:1">Enviar inscripción</button></div>
  </form>`;
}

ACT.regback = () => {
  const form = app.querySelector('form[data-form="reg2"]');
  if (form) for (const el of form.querySelectorAll('input')) S.reg.data[el.name] = el.type === 'checkbox' ? el.checked : el.value;
  S.reg.step = 1; render();
};

FORM.reg2 = async (fd, form, submitter) => {
  for (const el of form.querySelectorAll('input')) S.reg.data[el.name] = el.type === 'checkbox' ? el.checked : el.value;
  const d = S.reg.data;
  if (!d.consent_privacy) { showFieldErrors(form, { consent_privacy: 'Debes aceptar la política de privacidad para inscribirte' }); return; }
  if (submitter) { submitter.disabled = true; submitter.textContent = 'Enviando…'; }
  try {
    const res = await api('/auth/register', { method: 'POST', body: { ...d, photo: S.reg.photo } });
    S.lastReg = res;
    S.reg = { step: 1, data: {}, photo: null, errors: {} };
    location.hash = '/gracias';
  } catch (e) {
    if (submitter) { submitter.disabled = false; submitter.textContent = 'Enviar inscripción'; }
    toast(e.message, true);
    const f = e.fields || {};
    S.reg.errors = f;
    const step1 = ['first_name', 'last_name', 'email', 'phone', 'birth_date', 'licence', 'handicap', 'shirt_size', 'instagram', 'photo'];
    if (step1.some((k) => f[k])) { S.reg.step = 1; render(); } else showFieldErrors(form, f);
  }
};

function viewThanks() {
  const r = S.lastReg;
  return { html: `<div class="card thanks">
    <div class="ok">${icon('check')}</div>
    <h1>¡Gracias${r ? `, ${esc(r.first_name)}` : ''}!</h1>
    <p class="muted" style="font-size:17px">Hemos recibido tu inscripción en la ${esc(S.settings.league_name)}.</p>
    <div class="notice" style="text-align:left;margin:18px 0"><div class="row" style="flex-wrap:nowrap;align-items:flex-start"><span style="color:var(--green-700);flex:none">${icon('mail')}</span>
      <span>Te hemos enviado un correo${r ? ` a <b>${esc(r.email)}</b>` : ''} con un enlace para <b>crear tu contraseña</b>. Con ella podrás entrar en la plataforma, ver tu ficha y tus puntuaciones, y apuntarte a las próximas jornadas.</span></div></div>
    <p class="small muted">El enlace caduca en 72 horas. Si no lo ves en unos minutos, revisa la carpeta de spam o promociones.</p>
    ${r ? `<button class="btn secondary" data-act="resend" data-email="${esc(r.email)}">Reenviar el correo</button>` : '<a class="btn secondary" href="#/recuperar">Pedir un enlace nuevo</a>'}
    <p style="margin-top:18px"><a href="#/">Volver al inicio</a></p>
  </div>` };
}
ACT.resend = async (el) => {
  el.disabled = true;
  try { await api('/auth/forgot', { method: 'POST', body: { email: el.dataset.email } }); toast('Correo reenviado'); } catch (e) { toast(e.message, true); el.disabled = false; }
};

function viewPrivacy() {
  const L = legalEntity();
  return { html: `<article class="card legal form-mid">
    <div class="eyebrow">Versión ${esc(S.settings.privacy_version || '')}</div>
    <h1>Política de privacidad</h1>
    <p>En cumplimiento del Reglamento (UE) 2016/679 (RGPD) y de la Ley Orgánica 3/2018 (LOPDGDD), te informamos de cómo tratamos los datos que nos facilitas al inscribirte en la ${esc(S.settings.league_name)}.</p>
    <h2>1. Responsable del tratamiento</h2>
    <p>${L.name}, con CIF ${L.cif} y domicilio en ${L.address}. Contacto: ${L.email}.</p>
    <h2>2. Datos que tratamos</h2>
    <p>Nombre y apellidos, número de licencia federativa, fecha de nacimiento, hándicap, talla de polo, cuenta de Instagram (opcional), correo electrónico, teléfono y fotografía. También tus inscripciones, tarjetas y puntuaciones en la liga. En menores de 14 años, el nombre y email del padre, madre o tutor.</p>
    <h2>3. Finalidades y base jurídica</h2>
    <ul>
      <li><b>Gestionar tu participación en la liga</b> (inscripción, ficha de jugador, horarios de salida, clasificaciones y comunicaciones necesarias para ello). Base: la relación que se establece con tu inscripción (art. 6.1.b RGPD).</li>
      <li><b>Enviarte notificaciones y novedades</b> por correo, SMS o WhatsApp. Base: tu consentimiento (art. 6.1.a RGPD), si lo has marcado.</li>
      <li><b>Publicar tu imagen</b> (fotos y vídeos de las jornadas y tu foto de ficha) en la web y redes sociales de la liga, y mencionar tu cuenta de Instagram. Base: tu consentimiento (art. 6.1.a RGPD y LO 1/1982 de protección del derecho a la propia imagen), si lo has marcado.</li>
    </ul>
    <p>Las clasificaciones, con tu nombre y puntuación, son visibles para el resto de jugadores inscritos. Tus datos de contacto, fecha de nacimiento y licencia solo los ve el comité.</p>
    <h2>4. Conservación</h2>
    <p>Mientras participes en la liga y, después, durante el tiempo necesario para atender posibles responsabilidades. Las imágenes publicadas se retirarán cuando retires tu consentimiento, en la medida en que dependa de nosotros.</p>
    <h2>5. Destinatarios</h2>
    <p>No cedemos tus datos a terceros salvo obligación legal. Los datos se alojan en servidores de un proveedor de hosting situado en la Unión Europea, que actúa como encargado del tratamiento. Las imágenes que autorices se publicarán en redes sociales, cuyos titulares pueden tratar datos fuera de la UE conforme a sus propias políticas.</p>
    <h2>6. Tus derechos</h2>
    <p>Puedes acceder, rectificar o suprimir tus datos, oponerte o limitar su tratamiento y solicitar su portabilidad escribiendo a ${L.email}. Puedes <b>retirar tus consentimientos en cualquier momento</b> desde tu ficha («Mi ficha → Consentimientos»), sin que ello afecte a la licitud del tratamiento anterior. Si consideras que no se han respetado tus derechos, puedes reclamar ante la Agencia Española de Protección de Datos (www.aepd.es).</p>
    <h2>7. Menores de edad</h2>
    <p>Los menores de 14 años solo pueden inscribirse con la autorización de su padre, madre o tutor legal, que da también los consentimientos opcionales en su nombre.</p>
    <p class="small muted" style="margin-top:24px">Texto orientativo preparado para la plataforma. Debe revisarlo el responsable del tratamiento o su asesoría antes de publicarlo.</p>
  </article>` };
}

// ---------- Acceso ----------

async function viewSetPassword(token) {
  let info;
  try { info = await api(`/auth/token/${token}`); } catch (e) {
    return { html: `<div class="card empty form-narrow"><h2>Enlace no válido</h2><p>${esc(e.message)}</p><a class="btn" href="#/recuperar">Pedir un enlace nuevo</a></div>` };
  }
  return { html: `<form class="card form-narrow" data-form="setpw" data-token="${esc(token)}">
    <div class="eyebrow">${info.purpose === 'activate' ? 'Último paso' : 'Recuperar acceso'}</div>
    <h1>${info.purpose === 'activate' ? `Bienvenido, ${esc(info.first_name)}` : 'Nueva contraseña'}</h1>
    <p class="muted">${info.purpose === 'activate' ? 'Crea tu contraseña para entrar en la plataforma de la liga.' : 'Elige una contraseña nueva para tu cuenta.'}</p>
    ${field('password', 'Contraseña (mínimo 8 caracteres)', '<input id="f-password" name="password" type="password" minlength="8" autocomplete="new-password" required>')}
    ${field('password2', 'Repite la contraseña', '<input id="f-password2" name="password2" type="password" minlength="8" autocomplete="new-password" required>')}
    <label class="row small muted" style="margin:-4px 0 14px;gap:6px"><input type="checkbox" data-act-change="showpw"> Mostrar contraseña</label>
    <button class="btn block lg">${info.purpose === 'activate' ? 'Crear contraseña y entrar' : 'Guardar y entrar'}</button>
  </form>` };
}
CHANGE.showpw = (el) => { el.closest('form').querySelectorAll('input[type="password"], input[data-pw]').forEach((i) => { i.dataset.pw = '1'; i.type = el.checked ? 'text' : 'password'; }); };
FORM.setpw = async (fd, form) => {
  const pw = fd.get('password'), pw2 = fd.get('password2');
  if (pw.length < 8) { showFieldErrors(form, { password: 'Mínimo 8 caracteres' }); return; }
  if (pw !== pw2) { showFieldErrors(form, { password2: 'Las contraseñas no coinciden' }); return; }
  try {
    const { user } = await api('/auth/password', { method: 'POST', body: { token: form.dataset.token, password: pw } });
    await refreshMe(); S.me = user;
    toast('¡Listo! Ya estás dentro');
    location.hash = '/perfil';
  } catch (e) { toast(e.message, true); }
};

function viewForgot() {
  return { html: `<form class="card form-narrow" data-form="forgot">
    <h1>¿Olvidaste tu contraseña?</h1>
    <p class="muted">Escribe el email con el que te inscribiste y te enviaremos un enlace para crear una nueva. También sirve si no te llegó el correo de bienvenida.</p>
    ${field('email', 'Correo electrónico', '<input id="f-email" name="email" type="email" autocomplete="email" required>')}
    <button class="btn block">Enviar enlace</button>
    <p class="small" style="text-align:center;margin-top:14px"><a href="#/entrar">Volver a Entrar</a></p>
  </form>` };
}
FORM.forgot = async (fd, form) => {
  try {
    await api('/auth/forgot', { method: 'POST', body: { email: fd.get('email') } });
    form.innerHTML = `<div class="thanks"><div class="ok">${icon('mail')}</div><h2>Revisa tu correo</h2>
      <p class="muted">Si ese email está inscrito, recibirás en unos minutos un enlace para crear tu contraseña. Mira también en spam.</p><a class="btn secondary" href="#/entrar">Volver a Entrar</a></div>`;
  } catch (e) { toast(e.message, true); }
};

function viewLogin() {
  if (S.me) { location.hash = '/'; return { html: '' }; }
  return { html: `<form class="card form-narrow" data-form="login">
    <h1>Entrar</h1><p class="muted">Accede con tu cuenta de jugador.</p>
    ${field('email', 'Correo electrónico', '<input id="f-email" name="email" type="email" autocomplete="email" required>')}
    ${field('password', 'Contraseña', '<input id="f-password" name="password" type="password" autocomplete="current-password" required>')}
    <button class="btn block lg">Entrar</button>
    <p class="small" style="text-align:center;margin:14px 0 4px"><a href="#/recuperar">¿Olvidaste tu contraseña o no te llegó el correo?</a></p>
    <p class="small muted" style="text-align:center;margin:0">¿Aún no estás inscrito? <a href="#/registro">Inscríbete en la liga</a></p>
  </form>` };
}
FORM.login = async (fd) => {
  try { const { user } = await api('/auth/login', { method: 'POST', body: Object.fromEntries(fd) }); S.me = user; await refreshMe(); location.hash = user.role === 'admin' ? '/admin' : '/'; toast(`Hola, ${user.first_name || user.name}`); }
  catch (e) { toast(e.message, true); }
};

// ---------- Mi ficha ----------

function viewProfile() {
  needLogin();
  const u = S.me;
  return { html: `
    <div class="card row" style="gap:18px">
      <div style="position:relative">${avatar(u.id, u.name, S.hasPhoto, 'xl')}</div>
      <div style="flex:1;min-width:200px"><div class="eyebrow">Mi ficha</div><h1 style="margin:0">${esc(u.name)}</h1>
        <p class="muted" style="margin:4px 0 10px">Hándicap ${hcp(u.handicap)}${u.licence ? ` · licencia ${esc(u.licence)}` : ''}</p>
        <div class="row"><label class="btn soft small" for="me-photo" style="cursor:pointer">Cambiar foto</label><input id="me-photo" type="file" accept="image/*" class="hidden" data-act-change="mephoto">
          <a class="btn secondary small" href="#/jugador/${u.id}">Mis tarjetas</a>
          <button class="btn secondary small" data-act="logout">Salir</button></div></div>
    </div>
    <div class="grid grid-2">
      <form class="card" data-form="profile" novalidate>
        <h2>Mis datos</h2>
        <div class="fgrid">
          ${field('first_name', 'Nombre', `<input id="f-first_name" name="first_name" value="${esc(u.first_name)}" required>`)}
          ${field('last_name', 'Apellidos', `<input id="f-last_name" name="last_name" value="${esc(u.last_name)}" required>`)}
          ${field('phone', 'Teléfono', `<input id="f-phone" name="phone" type="tel" value="${esc(u.phone)}">`)}
          ${field('shirt_size', 'Talla de polo', `<select id="f-shirt_size" name="shirt_size">${['', ...SHIRT_SIZES].map((s) => `<option ${s === u.shirt_size ? 'selected' : ''} value="${s}">${s || '—'}</option>`).join('')}</select>`)}
          ${field('instagram', 'Instagram', `<input id="f-instagram" name="instagram" value="${esc(u.instagram ? `@${u.instagram}` : '')}" autocapitalize="none" placeholder="@tuusuario">`, { full: true, opt: true })}
        </div>
        <div class="fgrid">
          <div class="field"><label>Correo electrónico</label><input value="${esc(u.email)}" readonly></div>
          <div class="field"><label>Fecha de nacimiento</label><input value="${u.birth_date ? esc(fmtDate(u.birth_date, { day: 'numeric', month: 'long', year: 'numeric' })) : '—'}" readonly></div>
          <div class="field"><label>Licencia</label><input value="${esc(u.licence || '—')}" readonly></div>
          <div class="field"><label>Hándicap</label><input value="${hcp(u.handicap)}" readonly></div>
        </div>
        <p class="small muted">Email, licencia, fecha de nacimiento y hándicap los actualiza el comité. Si hay algún error, avísanos.</p>
        <button class="btn">Guardar cambios</button>
      </form>
      <div class="stack">
        <div class="card"><h2>Consentimientos</h2>
          <label class="switch"><span><b>Notificaciones de la liga</b><br><span class="small muted">Convocatorias, avisos y novedades por email, SMS o WhatsApp.</span></span>
            <input type="checkbox" data-act-change="consent" data-k="notifications" ${u.consent_notifications ? 'checked' : ''} aria-label="Notificaciones de la liga"></label>
          <label class="switch"><span><b>Publicación de mi imagen</b><br><span class="small muted">Fotos y vídeos de las jornadas y mi foto de ficha en la web y redes sociales de la liga.</span></span>
            <input type="checkbox" data-act-change="consent" data-k="image" ${u.consent_image ? 'checked' : ''} aria-label="Publicación de mi imagen"></label>
          <p class="small muted" style="margin:8px 0 0">Puedes cambiarlos cuando quieras. <a href="#/privacidad">Política de privacidad</a></p>
        </div>
        <form class="card" data-form="password">
          <h2>Cambiar contraseña</h2>
          ${field('current_password', 'Contraseña actual', '<input id="f-current_password" name="current_password" type="password" required autocomplete="current-password">')}
          ${field('new_password', 'Nueva contraseña (mín. 8)', '<input id="f-new_password" name="new_password" type="password" minlength="8" required autocomplete="new-password">')}
          <button class="btn secondary">Cambiar contraseña</button>
        </form>
      </div>
    </div>` };
}
FORM.profile = async (fd, form) => {
  try { const { user } = await api('/me', { method: 'PUT', body: Object.fromEntries(fd) }); S.me = user; toast('Datos guardados'); render(true); }
  catch (e) { toast(e.message, true); showFieldErrors(form, e.fields); }
};
FORM.password = async (fd, form) => { try { await api('/me', { method: 'PUT', body: Object.fromEntries(fd) }); form.reset(); toast('Contraseña cambiada'); } catch (e) { toast(e.message, true); } };
CHANGE.consent = async (el) => {
  try { const { user } = await api('/me/consents', { method: 'PUT', body: { [el.dataset.k]: el.checked } }); S.me = user; toast(el.checked ? 'Consentimiento activado' : 'Consentimiento retirado'); }
  catch (e) { el.checked = !el.checked; toast(e.message, true); }
};
CHANGE.mephoto = async (el) => {
  const file = el.files[0];
  if (!file) return;
  try { await api('/me/photo', { method: 'PUT', body: { photo: await resizePhoto(file) } }); S.hasPhoto = true; S.photoV = Date.now(); toast('Foto actualizada'); render(true); }
  catch (e) { toast(e.message, true); }
};
ACT.logout = async () => { await api('/auth/logout', { method: 'POST', body: {} }); S.me = null; S.hasPhoto = false; location.hash = '/'; render(); };

// ---------- Clasificaciones y jornadas ----------

function leaderboardTable(rows, live) {
  return `<div class="tablewrap"><table><thead><tr><th>Pos</th><th>Jugador</th><th class="c">HJ</th>${live ? '<th class="c">Hoyos</th>' : ''}<th class="c">Golpes</th><th class="r">Pts</th></tr></thead><tbody>
    ${rows.map((r) => `<tr class="link ${r.user_id === S.me?.id ? 'me' : ''}" data-act="go" data-href="#/tarjeta/${r.card_id}">
      <td class="pos">${r.pos}</td><td>${esc(r.name)}${r.status === 'validated' && live ? ' <span class="check" title="Tarjeta validada">✓</span>' : ''}</td>
      <td class="c">${r.playing_hcp}</td>${live ? `<td class="c">${r.thru === 9 ? (r.status === 'validated' ? 'F' : '9 · sin firmar') : r.thru}</td>` : ''}
      <td class="c">${r.gross} <span class="small muted">(${toPar(r.toPar)})</span></td><td class="r total">${r.points}</td></tr>`).join('')}
  </tbody></table></div>`;
}

async function viewStandings() {
  needLogin();
  const st = await api('/standings');
  return { live: true, html: `
    <div class="pagehead"><div class="eyebrow">Temporada ${esc(S.settings.season)}</div><h1>Clasificación general</h1>
      <p>Suma de las ${st.best_cards} mejores tarjetas validadas (Stableford neto). Las puntuaciones tachadas no cuentan. Desempate: mejor tarjeta y después suma de todas.</p></div>
    <div class="card">${st.rows.length ? `<div class="tablewrap"><table>
      <thead><tr><th>Pos</th><th class="sticky-col">Jugador</th>${st.rounds.map((r) => `<th class="c" title="Jornada ${r.number}">J${r.number}</th>`).join('')}<th class="c">Jug.</th><th class="r">Total</th></tr></thead>
      <tbody>${st.rows.map((r) => `<tr class="link ${r.user_id === S.me?.id ? 'me' : ''}" data-act="go" data-href="#/jugador/${r.user_id}">
        <td class="pos">${r.pos}</td><td class="sticky-col">${esc(r.name)} <span class="small muted">${hcp(r.handicap)}</span></td>
        ${st.rounds.map((rd) => { const x = r.byRound[rd.id]; return `<td class="c ${x && !x.counted ? 'dropped' : ''}">${x ? x.points : '<span class="muted">·</span>'}</td>`; }).join('')}
        <td class="c">${r.played}</td><td class="r total">${r.total}</td></tr>`).join('')}</tbody></table></div>`
      : '<p class="empty">Todavía no hay tarjetas validadas.</p>'}</div>` };
}

async function viewRounds() {
  needLogin();
  const { rounds } = await api('/rounds');
  return { live: true, html: `
    <div class="pagehead"><h1>Jornadas</h1><p>10 jornadas a 9 hoyos en ${esc(S.settings.course_name)}. Apúntate a las que vayas a jugar.</p></div>
    <div class="grid grid-2">${rounds.map((r) => `
      <div class="card">
        <div class="spread"><div class="eyebrow">Jornada ${r.number}</div>${statusBadge(r.status)}</div>
        <h3>${esc(fmtLong(r.date))}</h3>
        <p class="muted small">${nineLabel(r.nine)} · salida ${esc(r.first_tee)} · ${r.entries} inscritos${r.validated ? ` · ${r.validated} tarjetas validadas` : ''}</p>
        <div class="row"><a class="btn secondary small" href="#/jornada/${r.id}">${r.status === 'closed' ? 'Ver clasificación' : 'Ver jornada'}</a>
          ${r.status === 'scheduled' && !r.groups && !isAdmin() ? entryButton(r, true) : ''}</div>
      </div>`).join('')}</div>` };
}

async function viewRound(id) {
  needLogin();
  const d = await api(`/rounds/${id}`);
  const r = d.round;
  const t = tabs(`round${id}`, [['clas', r.status === 'live' ? 'Provisional' : 'Clasificación'], ['partidas', `Partidas (${d.groups.length})`], ['inscritos', `Inscritos (${d.entries.length})`]],
    r.status === 'scheduled' ? (d.groups.length ? 'partidas' : 'inscritos') : 'clas');
  let body = '';
  if (t.cur === 'clas') body = d.leaderboard.length ? leaderboardTable(d.leaderboard, r.status === 'live')
    : `<p class="empty">${r.status === 'scheduled' ? 'La jornada aún no se ha jugado.' : 'Sin tarjetas validadas todavía.'}</p>`;
  if (t.cur === 'partidas') body = d.groups.length ? `<div class="grid grid-2">${d.groups.map((g) => `
      <div class="card flat">
        <div class="spread"><h3>Partida ${g.number}</h3><span class="badge">Tee ${g.start_hole} · ${esc(g.tee_time)}</span></div>
        ${g.players.map((p) => `<div class="spread" style="padding:6px 0;border-top:1px solid var(--line)">
          <span><a href="#/tarjeta/${p.card_id}">${esc(p.name)}</a> <span class="small muted">HJ ${p.playing_hcp}</span></span>
          <span class="small muted">marca a ${esc(g.players.find((q) => q.marker_id === p.id)?.name || '—')}</span></div>`).join('')}
      </div>`).join('')}</div>` : '<p class="empty">El comité todavía no ha publicado las partidas y horarios.</p>';
  if (t.cur === 'inscritos') body = d.entries.length ? `<table><thead><tr><th>Jugador</th><th class="r">Hándicap</th></tr></thead><tbody>
      ${d.entries.map((e) => `<tr class="${e.id === S.me.id ? 'me' : ''}"><td><a href="#/jugador/${e.id}">${esc(e.name)}</a></td><td class="r">${hcp(e.handicap)}</td></tr>`).join('')}</tbody></table>`
    : '<p class="empty">Nadie inscrito todavía. ¡Sé el primero!</p>';
  return { live: true, html: `
    <div class="pagehead spread"><div><div class="eyebrow">Jornada ${r.number} · ${nineLabel(r.nine)}</div><h1>${esc(fmtLong(r.date))}</h1></div>${statusBadge(r.status)}</div>
    ${r.status === 'scheduled' && !isAdmin() ? `<div class="card" style="margin-bottom:16px"><div class="spread"><span>${d.entered ? '<b>Estás inscrito en esta jornada.</b>' : '¿Juegas esta jornada?'}</span>
      ${entryButton({ ...r, groups: d.groups.length, entered: d.entered })}</div></div>` : ''}
    <div class="card">${t.html}${body}</div>` };
}

async function viewCard(id) {
  needLogin();
  const { card: c } = await api(`/cards/${id}`);
  const st = c.status === 'validated' ? '<span class="badge">✓ Validada</span>' : c.status === 'playing' ? '<span class="badge live">En juego</span>' : '<span class="badge closed">Pendiente</span>';
  const editing = isAdmin() && S.tab.editCard === c.id;
  const rows = c.holes.map((h) => `<tr>
    <td><b>${h.hole}</b> <span class="small muted">${h.meters ? `${h.meters} m` : ''}</span></td><td>${h.par}</td><td class="muted">${h.si}</td><td class="dots">${dots(h.received)}</td>
    <td>${editing ? `<input class="inline-input" type="number" min="1" max="15" name="h${h.hole}" value="${h.strokes ?? ''}" inputmode="numeric">`
      : h.strokes ? `<span class="score ${scoreCls(h.strokes, h.par)}">${h.strokes}</span>` : '<span class="muted">–</span>'}</td>
    <td>${h.points === null ? '' : `<span class="pts ${ptsCls(h.points)}">${h.points}</span>`}</td></tr>`).join('');
  return { html: `
    <div class="pagehead"><div class="eyebrow"><a href="#/jornada/${c.round.id}">Jornada ${c.round.number}</a> · ${esc(fmtDate(c.round.date))} · ${nineLabel(c.round.nine)}</div>
      <div class="spread"><h1><a href="#/jugador/${c.player.id}" style="color:inherit;text-decoration:none">${esc(c.player.name)}</a></h1>${st}</div>
      <p>Hándicap ${hcp(c.handicap)} · hándicap de juego ${c.playing_hcp}${c.group ? ` · partida ${c.group.number}, tee ${c.group.start_hole} a las ${esc(c.group.tee_time)}` : ''}${c.marker ? ` · marcador: ${esc(c.marker.name)}` : ''}</p></div>
    <div class="grid grid-2">
      <form class="card" data-form="cardfix" data-id="${c.id}">
        <div class="tablewrap"><table class="scorecard"><thead><tr><th>Hoyo</th><th>Par</th><th>SI</th><th>Recibe</th><th>Golpes</th><th>Pts</th></tr></thead>
          <tbody>${rows}</tbody>
          <tfoot><tr><th>Total</th><th>${c.par}</th><th></th><th>${c.playing_hcp}</th><th class="total">${c.gross || '–'}</th><th class="total">${c.points}</th></tr></tfoot></table></div>
        ${editing ? `<div class="row" style="margin-top:12px"><button class="btn" name="mode" value="save">Guardar corrección</button>
          <button class="btn secondary" name="mode" value="validate">Guardar y validar</button><button class="btn secondary" name="mode" value="reopen">Reabrir tarjeta</button>
          <button type="button" class="btn secondary" data-act="editcard" data-id="">Cancelar</button></div>
          <p class="small muted">Las correcciones del comité quedan registradas en la auditoría.</p>` : ''}
      </form>
      <div class="stack">
        <div class="card"><div class="stats" style="margin-top:0">
          <div class="stat"><b>${c.points}</b><span>puntos Stableford</span></div>
          <div class="stat"><b>${c.gross || '–'}</b><span>golpes (${toPar(c.toPar)})</span></div>
          <div class="stat"><b>${c.thru}/9</b><span>hoyos</span></div></div></div>
        <div class="card"><h3>Validación</h3>
          <p>${c.player_signed_at ? '<span class="check">✓</span>' : '○'} Jugador: ${esc(c.player.name)}</p>
          <p>${c.marker_signed_at ? '<span class="check">✓</span>' : '○'} Marcador: ${esc(c.marker?.name || 'Comité')}</p>
          ${c.validated_at ? `<p class="small muted">Validada el ${fmtDateTime(c.validated_at)}</p>` : ''}
          <p class="small muted">Los jugadores no pueden modificar sus puntuaciones. Solo el comité puede corregirlas.</p>
          ${isAdmin() && !editing ? `<button class="btn secondary" data-act="editcard" data-id="${c.id}">Corregir tarjeta (comité)</button>` : ''}
        </div>
      </div>
    </div>` };
}
ACT.editcard = (el) => { S.tab.editCard = Number(el.dataset.id) || null; render(true); };
FORM.cardfix = async (fd, form, submitter) => {
  const scores = {};
  for (const [k, v] of fd) if (k.startsWith('h')) scores[k.slice(1)] = v === '' ? null : Number(v);
  const mode = submitter?.value || 'save';
  try {
    await api(`/admin/cards/${form.dataset.id}`, { method: 'PUT', body: { scores, status: mode === 'validate' ? 'validated' : mode === 'reopen' ? 'playing' : undefined } });
    S.tab.editCard = null; toast('Tarjeta actualizada'); render(true);
  } catch (e) { toast(e.message, true); }
};

// ---------- Jugadores ----------

async function viewPlayers() {
  needLogin();
  const { players } = await api('/players');
  return { html: `
    <div class="pagehead"><h1>Jugadores</h1><p>${players.length} golfistas en la liga.</p></div>
    <div class="grid grid-3">${players.map((p) => `
      <a class="card row" href="#/jugador/${p.id}" style="text-decoration:none;color:inherit;margin:0">
        ${avatar(p.id, p.name, p.has_photo)}
        <span style="flex:1;min-width:0"><b>${esc(p.name)}</b><br><span class="small muted">Hcp ${hcp(p.handicap)}${p.pos ? ` · ${p.pos}º · ${p.total} pts` : ''}</span></span>
      </a>`).join('') || '<p class="empty">Todavía no hay jugadores activos.</p>'}</div>` };
}

async function viewPlayer(id) {
  needLogin();
  const { player: p, standing: s, cards } = await api(`/players/${id}`);
  const mine = S.me?.id === p.id;
  return { html: `
    <div class="card row" style="gap:18px">
      ${avatar(p.id, p.name, p.has_photo, 'lg')}
      <div style="flex:1;min-width:200px"><h1 style="margin:0">${esc(p.name)}</h1>
        <p class="muted" style="margin:0">Hándicap ${hcp(p.handicap)}${p.licence ? ` · licencia ${esc(p.licence)}` : ''}${p.instagram ? ` · <a href="https://instagram.com/${esc(p.instagram)}" target="_blank" rel="noopener">@${esc(p.instagram)}</a>` : ''}</p>
        ${p.bio ? `<p style="margin:8px 0 0">${esc(p.bio)}</p>` : ''}</div>
      ${mine ? '<a class="btn secondary" href="#/perfil">Editar mi ficha</a>' : ''}
    </div>
    <div class="card"><div class="stats" style="margin-top:0">
      <div class="stat"><b>${s ? `${s.pos}º` : '–'}</b><span>en la general</span></div>
      <div class="stat"><b>${s?.total ?? 0}</b><span>puntos (mejores ${S.settings.best_cards})</span></div>
      <div class="stat"><b>${s?.best ?? '–'}</b><span>mejor tarjeta</span></div></div></div>
    <div class="card"><h2>Tarjetas por jornada</h2>
      ${cards.length ? `<div class="tablewrap"><table><thead><tr><th>Jornada</th><th>Fecha</th><th class="c">HJ</th><th class="c">Golpes</th><th class="c">Pts</th><th>Estado</th></tr></thead><tbody>
        ${cards.map((c) => { const x = s?.byRound[c.round.id]; return `<tr class="link" data-act="go" data-href="#/tarjeta/${c.id}">
          <td><b>J${c.round.number}</b></td><td>${esc(fmtDate(c.round.date))}</td><td class="c">${c.playing_hcp}</td><td class="c">${c.gross || '–'}</td>
          <td class="c"><span class="pts ${ptsCls(c.points)} ${x && !x.counted ? 'dropped' : ''}">${c.points}</span></td>
          <td>${c.status === 'validated' ? (x?.counted ? '<span class="badge">Cuenta</span>' : '<span class="badge closed">Descartada</span>') : c.status === 'playing' ? '<span class="badge live">En juego</span>' : '<span class="badge closed">Pendiente</span>'}</td></tr>`; }).join('')}
      </tbody></table></div>` : `<p class="empty">${mine ? 'Aún no has jugado ninguna jornada. <a href="#/jornadas">Apúntate a la próxima</a>.' : 'Aún no ha jugado ninguna jornada.'}</p>`}
    </div>` };
}

// ---------- Tarjeta live (borrador) ----------

const draftNotice = (k) => (!feature(k) && isAdmin() ? `<div class="notice amber" style="margin-bottom:16px"><b>Borrador.</b> Esta sección solo la ve el comité. Actívala en Comité → Ajustes cuando esté lista.</div>` : '');

async function viewLive() {
  needLogin();
  if (!canSee('live')) return { html: '<div class="card empty"><h2>Próximamente</h2><p>La tarjeta en directo estará disponible más adelante.</p></div>' };
  const d = await api('/live');
  S.live = d;
  if (!d.round) {
    return { live: true, html: `${draftNotice('live')}<div class="card empty"><h2>No hay ninguna jornada en juego</h2>
      ${d.next ? `<p>La próxima es la jornada ${d.next.number}, el ${esc(fmtLong(d.next.date))} (${nineLabel(d.next.nine)}).</p><a class="btn" href="#/jornada/${d.next.id}">Ver jornada</a>` : ''}</div>` };
  }
  const head = `${draftNotice('live')}<div class="pagehead spread"><div><div class="eyebrow"><span class="livedot"></span>En directo</div><h1>Jornada ${d.round.number}</h1></div>
    <span class="muted small">${esc(fmtDate(d.round.date))} · ${nineLabel(d.round.nine)}</span></div>`;
  if (!d.group) {
    return { live: true, html: `${head}<div class="notice" style="margin-bottom:16px">No tienes partida asignada en esta jornada. Puedes seguir la clasificación provisional.</div>
      <div class="card"><h2>Clasificación provisional</h2>${d.leaderboard.length ? leaderboardTable(d.leaderboard, true) : '<p class="empty">Aún no hay golpes anotados.</p>'}</div>` };
  }
  const t = tabs('live', [['card', 'Mi partida'], ['board', 'Clasificación provisional']], 'card');
  return { live: true, html: `${head}${t.html}${t.cur === 'card' ? liveCard(d) : `<div class="card">${d.leaderboard.length ? leaderboardTable(d.leaderboard, true) : '<p class="empty">Aún no hay golpes anotados.</p>'}</div>`}` };
}

function liveCard(d) {
  const { group: g, cards } = d;
  const order = cards[0].holes.map((h) => h.hole);
  const firstOpen = order.findIndex((_, i) => cards.some((c) => c.status !== 'validated' && !c.holes[i].strokes));
  const idx = Math.min(S.liveHole[g.id] ?? (firstOpen === -1 ? order.length - 1 : firstOpen), order.length - 1);
  const h = cards[0].holes[idx];
  const minThru = Math.min(...cards.map((c) => c.thru));
  const mine = cards.find((c) => c.player.id === S.me.id);
  const iMark = cards.find((c) => c.marker?.id === S.me.id);
  const allDone = (i) => cards.every((c) => c.holes[i].strokes);

  const header = `<div class="livehead">
    <div class="spread"><div><b>Partida ${g.number}</b> <span class="muted">· salida por el hoyo ${g.start_hole} a las ${esc(g.tee_time)}</span></div>
      ${g.started_at ? `<div class="row"><span class="pace" data-pace data-start="${esc(g.started_at)}" data-end="${esc(g.finished_at || '')}" data-thru="${minThru}" data-target="${d.pace_minutes}"></span>
        <span class="timer" data-since="${esc(g.started_at)}" data-end="${esc(g.finished_at || '')}">0:00</span></div>` : ''}</div>
    ${g.started_at ? '' : `<p class="muted" style="margin:10px 0">Cuando estéis en el tee, pulsa empezar para poner en marcha el tiempo de juego.</p>
      <button class="btn secondary block" data-act="startgroup" data-id="${g.id}">Empezar partida</button>`}
    <div class="holestrip">${order.map((n, i) => `<button class="${i === idx ? 'cur' : allDone(i) ? 'done' : ''}" data-act="hole" data-g="${g.id}" data-i="${i}" aria-label="Hoyo ${n}">${n}</button>`).join('')}</div>
  </div>`;

  const holeCard = `<div class="card holecard">
    <div class="holetitle">
      <button class="iconbtn" data-act="hole" data-g="${g.id}" data-i="${idx - 1}" ${idx === 0 ? 'disabled' : ''} aria-label="Hoyo anterior">‹</button>
      <div style="text-align:center"><div class="small muted">Hoyo ${idx + 1} de 9</div><div class="big">${h.hole}</div>
        <div class="small muted">Par ${h.par} · SI ${h.si}${h.meters ? ` · ${h.meters} m` : ''}</div></div>
      <button class="iconbtn" data-act="hole" data-g="${g.id}" data-i="${idx + 1}" ${idx === order.length - 1 ? 'disabled' : ''} aria-label="Hoyo siguiente">›</button>
    </div>
    ${cards.map((c) => { const ch = c.holes[idx]; const locked = c.status === 'validated'; return `
      <div class="prow">
        <div class="who"><b>${esc(c.player.name)}${c.player.id === S.me.id ? ' (tú)' : ''}</b>
          <span class="small muted">HJ ${c.playing_hcp}${ch.received ? ` · recibe <span class="dots">${dots(ch.received)}</span>` : ''} · ${c.points} pts</span>
          ${ch.points !== null ? ` <span class="pts ${ptsCls(ch.points)}">${ch.points} pts</span>` : ''}${locked ? ' <span class="badge">✓ Validada</span>' : ''}</div>
        <div class="stepper">
          <button data-act="stroke" data-card="${c.id}" data-hole="${ch.hole}" data-v="${ch.strokes ? ch.strokes - 1 : ''}" ${locked || !ch.strokes ? 'disabled' : ''} aria-label="Un golpe menos">−</button>
          <button class="val ${ch.strokes ? '' : 'empty'}" data-act="stroke" data-card="${c.id}" data-hole="${ch.hole}" data-v="${ch.strokes || ch.par}" ${locked ? 'disabled' : ''}>${ch.strokes || 'Par'}</button>
          <button data-act="stroke" data-card="${c.id}" data-hole="${ch.hole}" data-v="${(ch.strokes || ch.par) + 1}" ${locked ? 'disabled' : ''} aria-label="Un golpe más">+</button>
        </div>
      </div>`; }).join('')}
    ${allDone(idx) && idx < order.length - 1 ? `<button class="btn block" style="margin-top:10px" data-act="hole" data-g="${g.id}" data-i="${idx + 1}">Siguiente hoyo →</button>` : ''}
  </div>`;

  const signs = [];
  if (mine && mine.status !== 'validated' && mine.complete && !mine.player_signed_at)
    signs.push(`<button class="btn block" data-act="sign" data-id="${mine.id}" data-as="player">Firmo mi tarjeta · ${mine.points} pts (${mine.gross} golpes)</button>`);
  if (iMark && iMark.status !== 'validated' && iMark.complete && !iMark.marker_signed_at)
    signs.push(`<button class="btn block secondary" data-act="sign" data-id="${iMark.id}" data-as="marker">Firmo como marcador de ${esc(iMark.player.name)} · ${iMark.points} pts</button>`);

  const summary = `<div class="card"><h3>Resumen de la partida</h3>
    <div class="tablewrap"><table><thead><tr><th>Jugador</th><th class="c">Hoyos</th><th class="c">Golpes</th><th class="c">Pts</th><th>Firmas</th></tr></thead><tbody>
    ${cards.map((c) => `<tr class="link" data-act="go" data-href="#/tarjeta/${c.id}"><td>${esc(c.player.name)}<br><span class="small muted">marca: ${esc(c.marker?.name || 'comité')}</span></td>
      <td class="c">${c.thru}</td><td class="c">${c.gross || '–'}</td><td class="c total">${c.points}</td>
      <td>${c.status === 'validated' ? '<span class="badge">✓ Validada</span>' : `<span class="small">${c.player_signed_at ? '✓' : '○'} jugador<br>${c.marker_signed_at ? '✓' : '○'} marcador</span>`}</td></tr>`).join('')}
    </tbody></table></div>
    ${signs.length ? `<div class="signbox stack" style="margin-top:14px"><p style="margin:0"><b>Tarjetas completas.</b> Revisad los golpes y firmad. Con la firma del jugador y la del marcador la tarjeta queda validada y sube a la clasificación.</p>${signs.join('')}</div>` : ''}
    <p class="small muted" style="margin-top:10px">Cualquier jugador de la partida puede anotar. Si se cambia un golpe después de firmar, las firmas se anulan.</p>
  </div>`;
  return `<div class="stack">${header}${holeCard}${summary}</div>`;
}

ACT.hole = (el) => { S.liveHole[el.dataset.g] = Math.max(0, Number(el.dataset.i)); render(true); };
ACT.startgroup = async (el) => {
  try { await api(`/groups/${el.dataset.id}/start`, { method: 'POST', body: {} }); toast('¡Buen golf! Tiempo en marcha'); render(true); } catch (e) { toast(e.message, true); }
};
ACT.stroke = async (el) => {
  const v = el.dataset.v === '' ? null : Number(el.dataset.v);
  if (v !== null && (v < 1 || v > 15)) return;
  app.querySelectorAll('[data-act="stroke"]').forEach((b) => { b.disabled = true; });
  try { await api(`/cards/${el.dataset.card}/score`, { method: 'PUT', body: { hole: Number(el.dataset.hole), strokes: v } }); }
  catch (e) { toast(e.message, true); }
  render(true);
};
ACT.sign = async (el) => {
  const as = el.dataset.as;
  if (!confirm(as === 'player' ? '¿Confirmas que tu tarjeta es correcta? Una vez validada no podrás modificarla.' : '¿Confirmas como marcador que esta tarjeta es correcta?')) return;
  try { const { card } = await api(`/cards/${el.dataset.id}/sign`, { method: 'POST', body: { as } });
    toast(card.status === 'validated' ? 'Tarjeta validada: ya cuenta para la clasificación' : 'Firma registrada'); render(true); } catch (e) { toast(e.message, true); }
};

function tickTimers() {
  document.querySelectorAll('[data-since]').forEach((el) => {
    const end = el.dataset.end ? new Date(el.dataset.end) : new Date();
    const s = Math.max(0, Math.floor((end - new Date(el.dataset.since)) / 1000));
    el.textContent = `${Math.floor(s / 3600)}:${String(Math.floor((s % 3600) / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  });
  document.querySelectorAll('[data-pace]').forEach((el) => {
    const thru = Number(el.dataset.thru);
    const end = el.dataset.end ? new Date(el.dataset.end) : new Date();
    const elapsed = (end - new Date(el.dataset.start)) / 60000;
    if (!thru) { el.textContent = 'Ritmo: —'; el.className = 'pace'; return; }
    const diff = Math.round(elapsed - (Number(el.dataset.target) / 9) * thru);
    el.textContent = diff > 5 ? `Ritmo +${diff} min` : 'En tiempo';
    el.className = `pace ${diff > 10 ? 'late' : ''}`;
  });
}
setInterval(tickTimers, 1000);

// ---------- Tienda (borrador) ----------

const shirtSvg = (color, accent) => `<svg viewBox="0 0 120 110" aria-hidden="true">
  <path d="M40 8 L18 18 L4 42 L22 52 L28 42 L28 104 L92 104 L92 42 L98 52 L116 42 L102 18 L80 8 C76 16 68 20 60 20 C52 20 44 16 40 8 Z" fill="${esc(color)}" stroke="rgba(0,0,0,.14)" stroke-width="1.5"/>
  <path d="M40 8 L52 30 L60 22 L68 30 L80 8 C76 16 68 20 60 20 C52 20 44 16 40 8 Z" fill="${esc(accent)}"/>
  <path d="M60 22 V44" stroke="${esc(accent)}" stroke-width="2"/><circle cx="60" cy="31" r="1.6" fill="${esc(accent)}"/><circle cx="60" cy="39" r="1.6" fill="${esc(accent)}"/>
  <circle cx="80" cy="44" r="5" fill="${esc(accent)}" opacity=".9"/></svg>`;

async function viewShop() {
  needLogin();
  if (!canSee('shop')) return { html: '<div class="card empty"><h2>Próximamente</h2><p>La tienda de la liga estará disponible más adelante.</p></div>' };
  const [{ products }, orders] = await Promise.all([api('/products'), api('/orders/mine')]);
  const byId = Object.fromEntries(products.map((p) => [p.id, p]));
  S.cart = S.cart.filter((l) => byId[l.productId]);
  const total = S.cart.reduce((s, l) => s + byId[l.productId].price_cents * l.qty, 0);
  const ST = { pendiente_pago: ['Pendiente de pago', 'amber'], pagado: ['Pagado', 'blue'], entregado: ['Entregado', ''], cancelado: ['Cancelado', 'closed'] };
  return { html: `${draftNotice('shop')}
    <div class="pagehead"><div class="eyebrow">Tienda de la liga</div><h1>Equipación oficial</h1><p>Polos y camisetas de la temporada ${esc(S.settings.season)}. Recogida en el club o en la próxima jornada.</p></div>
    <div class="grid grid-3">${products.map((p) => { const sel = S.shopSel[p.id] || (S.me?.shirt_size && p.sizes.includes(S.me.shirt_size) ? S.me.shirt_size : ''); return `
      <div class="card product">
        <div class="shirt">${shirtSvg(p.color, p.accent)}</div>
        <h3>${esc(p.name)}</h3><p class="small muted">${esc(p.description)}</p>
        <div class="spread"><span class="price">${euros(p.price_cents)}</span><span class="small muted">${p.stock > 0 ? (p.stock < 10 ? `Quedan ${p.stock}` : 'En stock') : 'Agotado'}</span></div>
        <div class="sizes" role="group" aria-label="Talla">${p.sizes.map((s) => `<button class="${s === sel ? 'sel' : ''}" data-act="size" data-p="${p.id}" data-s="${s}" aria-pressed="${s === sel}">${s}</button>`).join('')}</div>
        <button class="btn block" data-act="addcart" data-p="${p.id}" data-s="${sel}" ${p.stock > 0 ? '' : 'disabled'}>Añadir al carrito</button>
      </div>`; }).join('')}</div>
    <div class="grid grid-2" style="margin-top:16px">
      <form class="card" data-form="order">
        <h2>Tu carrito</h2>
        ${S.cart.length ? `<table><tbody>${S.cart.map((l, i) => `<tr><td>${esc(byId[l.productId].name)}<br><span class="small muted">Talla ${esc(l.size)}</span></td>
          <td class="c"><div class="row" style="gap:4px;flex-wrap:nowrap"><button type="button" class="btn secondary small" data-act="qty" data-i="${i}" data-d="-1">−</button><span class="num">${l.qty}</span><button type="button" class="btn secondary small" data-act="qty" data-i="${i}" data-d="1">+</button></div></td>
          <td class="r">${euros(byId[l.productId].price_cents * l.qty)}</td></tr>`).join('')}
          <tr><td><b>Total</b></td><td></td><td class="r total">${euros(total)}</td></tr></tbody></table>
          <div class="field" style="margin-top:12px"><label for="delivery">Entrega</label><select id="delivery" name="delivery"><option value="club">Recoger en el club</option><option value="jornada">Entregar en la próxima jornada</option></select></div>
          <div class="field"><label for="notes">Notas (opcional)</label><input id="notes" name="notes" maxlength="300"></div>
          <p class="notice small">El pago se realiza en el club al recoger el pedido.</p>
          <button class="btn block">Hacer pedido</button>`
        : '<p class="empty">El carrito está vacío. Elige talla y añade un producto.</p>'}
      </form>
      <div class="card"><h2>Mis pedidos</h2>${orders.orders.length ? orders.orders.map((o) => `
        <div style="padding:10px 0;border-top:1px solid var(--line)"><div class="spread"><b>Pedido #${o.id}</b><span class="badge ${ST[o.status][1]}">${ST[o.status][0]}</span></div>
          <p class="small muted" style="margin:0">${o.items.map((i) => `${i.qty}× ${esc(i.name)} (${esc(i.size)})`).join(', ')} · ${euros(o.total_cents)}</p></div>`).join('')
        : '<p class="empty">Aún no has hecho ningún pedido.</p>'}</div>
    </div>` };
}
ACT.size = (el) => { S.shopSel[el.dataset.p] = el.dataset.s; render(true); };
ACT.addcart = (el) => {
  if (!el.dataset.s) { toast('Elige una talla primero', true); return; }
  const pid = Number(el.dataset.p);
  const line = S.cart.find((l) => l.productId === pid && l.size === el.dataset.s);
  if (line) line.qty++; else S.cart.push({ productId: pid, size: el.dataset.s, qty: 1 });
  saveCart(); toast('Añadido al carrito'); render(true);
};
ACT.qty = (el) => {
  const l = S.cart[Number(el.dataset.i)];
  l.qty += Number(el.dataset.d);
  if (l.qty <= 0) S.cart.splice(Number(el.dataset.i), 1);
  saveCart(); render(true);
};
FORM.order = async (fd) => {
  try {
    const { order } = await api('/orders', { method: 'POST', body: { items: S.cart, delivery: fd.get('delivery'), notes: fd.get('notes') } });
    S.cart = []; saveCart(); toast(`Pedido #${order.id} realizado`); render(true);
  } catch (e) { toast(e.message, true); }
};

// ---------- Comité ----------

async function viewAdmin() {
  needLogin();
  if (!isAdmin()) return { html: '<div class="card empty"><h2>Acceso solo para el comité</h2></div>' };
  const ov = await api('/admin/overview');
  const pend = ov.players.filter((p) => p.role === 'player' && p.status === 'pending').length;
  const t = tabs('admin', [['jugadores', `Inscripciones${pend ? ` (${pend} pend.)` : ''}`], ['jornadas', 'Jornadas'], ['campo', 'Campo'], ['tienda', 'Tienda'], ['ajustes', 'Ajustes'], ['audit', 'Auditoría']], 'jugadores');
  let body = '';
  if (t.cur === 'jugadores') body = adminPlayers(ov);
  if (t.cur === 'jornadas') {
    const { rounds } = await api('/rounds');
    body = await adminRounds(rounds, ov.players.filter((p) => p.role === 'player' && p.status === 'active'));
  }
  if (t.cur === 'campo') {
    const course = await api('/course');
    body = `<form data-form="course"><p class="notice amber small">Revisa par, índice (SI) y metros con la tarjeta oficial de ${esc(S.settings.course_name)}.</p>
    <div class="tablewrap"><table><thead><tr><th>Hoyo</th><th>Par</th><th>SI</th><th>Metros</th></tr></thead><tbody>
    ${course.holes.map((h) => `<tr><td><b>${h.hole}</b></td><td><input class="inline-input" name="par${h.hole}" type="number" min="3" max="6" value="${h.par}"></td>
      <td><input class="inline-input" name="si${h.hole}" type="number" min="1" max="18" value="${h.si}"></td><td><input class="inline-input" style="width:84px" name="m${h.hole}" type="number" value="${h.meters}"></td></tr>`).join('')}
    </tbody></table></div><button class="btn" style="margin-top:12px">Guardar campo</button></form>`;
  }
  if (t.cur === 'tienda') body = `${!feature('shop') ? '<p class="notice amber small">La tienda está en borrador: los jugadores no la ven.</p>' : ''}<h3>Pedidos</h3>${ov.orders.length ? `<div class="tablewrap"><table><thead><tr><th>#</th><th>Jugador</th><th>Artículos</th><th>Total</th><th>Estado</th></tr></thead><tbody>
    ${ov.orders.map((o) => `<tr><td>${o.id}</td><td>${esc(o.user_name || '—')}</td><td class="small">${o.items.map((i) => `${i.qty}× ${esc(i.name)} (${esc(i.size)})`).join('<br>')}</td>
      <td>${euros(o.total_cents)}</td>
      <td><select data-act-change="orderstatus" data-id="${o.id}" style="width:auto">${['pendiente_pago', 'pagado', 'entregado', 'cancelado'].map((s) => `<option ${s === o.status ? 'selected' : ''} value="${s}">${s.replace('_', ' ')}</option>`).join('')}</select></td></tr>`).join('')}
    </tbody></table></div>` : '<p class="empty">Sin pedidos todavía.</p>'}
    <h3 style="margin-top:20px">Productos</h3><div class="tablewrap"><table><thead><tr><th>Producto</th><th>Precio (€)</th><th>Stock</th><th>Activo</th><th></th></tr></thead><tbody>
    ${ov.products.map((p) => `<tr data-row="${p.id}"><td><input name="name" value="${esc(p.name)}" style="min-width:180px"></td><td><input class="inline-input" style="width:84px" name="price" type="number" step="0.01" value="${(p.price_cents / 100).toFixed(2)}"></td>
      <td><input class="inline-input" name="stock" type="number" value="${p.stock}"></td><td class="c"><input type="checkbox" name="active" ${p.active ? 'checked' : ''}></td>
      <td><button class="btn small" data-act="saveproduct" data-id="${p.id}">Guardar</button></td></tr>`).join('')}</tbody></table></div>`;
  if (t.cur === 'ajustes') {
    const s = ov.settings;
    body = `<form data-form="settings" class="form-mid" style="margin:0">
    <div class="notice ${s.legal_name && s.legal_cif && s.legal_email ? '' : 'amber'} small" style="margin-bottom:14px">${s.legal_name && s.legal_cif && s.legal_email ? 'Datos del responsable del tratamiento completos.' : '<b>Antes de abrir la inscripción</b>, completa los datos del responsable del tratamiento: aparecen en la página de privacidad y en el formulario de inscripción.'}</div>
    <h3>Responsable del tratamiento (RGPD)</h3>
    <div class="fgrid">
      <div class="field"><label>Razón social o nombre</label><input name="legal_name" value="${esc(s.legal_name)}" placeholder="Club / Asociación…"></div>
      <div class="field"><label>CIF / NIF</label><input name="legal_cif" value="${esc(s.legal_cif)}"></div>
      <div class="field full"><label>Dirección</label><input name="legal_address" value="${esc(s.legal_address)}"></div>
      <div class="field full"><label>Email para ejercer derechos</label><input name="legal_email" type="email" value="${esc(s.legal_email)}"></div>
    </div>
    <h3 style="margin-top:10px">Secciones en borrador</h3>
    <label class="switch"><span><b>Tarjeta live</b><br><span class="small muted">Anotación en directo y clasificación provisional durante la jornada.</span></span><input type="checkbox" name="feature_live" ${s.feature_live ? 'checked' : ''}></label>
    <label class="switch"><span><b>Tienda</b><br><span class="small muted">Venta de polos y camisetas.</span></span><input type="checkbox" name="feature_shop" ${s.feature_shop ? 'checked' : ''}></label>
    <p class="small muted">Desactivadas, solo las ve el comité (marcadas como «borrador»).</p>
    <h3 style="margin-top:10px">Liga</h3>
    <div class="fgrid">
      <div class="field"><label>Nombre de la liga</label><input name="league_name" value="${esc(s.league_name)}"></div>
      <div class="field"><label>Campo</label><input name="course_name" value="${esc(s.course_name)}"></div>
      <div class="field"><label>Temporada</label><input name="season" value="${esc(s.season)}"></div>
      <div class="field"><label>Tarjetas que cuentan</label><input name="best_cards" type="number" min="1" max="10" value="${s.best_cards}"></div>
      <div class="field"><label>% de hándicap aplicado</label><input name="allowance" type="number" min="50" max="100" value="${s.allowance}"></div>
      <div class="field"><label>Tiempo objetivo 9 hoyos (min)</label><input name="pace_minutes" type="number" min="60" max="240" value="${s.pace_minutes}"></div>
    </div>
    <p class="small muted">Correo: ${esc(ov.mail)}</p>
    <button class="btn">Guardar ajustes</button></form>`;
  }
  if (t.cur === 'audit') body = ov.audit.length ? `<div class="tablewrap"><table><thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Detalle</th></tr></thead><tbody>
    ${ov.audit.map((a) => `<tr><td class="small">${fmtDateTime(a.created_at)}</td><td>${esc(a.user_name || '')}</td><td>${esc(a.action)}</td><td class="small" style="white-space:normal;max-width:420px">${esc(a.detail)}</td></tr>`).join('')}
    </tbody></table></div>` : '<p class="empty">Sin actividad registrada.</p>';
  return { html: `<div class="pagehead"><div class="eyebrow">Comité de competición</div><h1>Gestión de la liga</h1></div><div class="card">${t.html}${body}</div>` };
}

function adminPlayers(ov) {
  const players = ov.players.filter((p) => p.role === 'player');
  const count = (s) => players.filter((p) => p.status === s).length;
  const sel = players.find((p) => p.id === S.adminPlayer);
  const yes = (v) => (v ? '<span class="check" title="Sí">✓</span>' : '<span class="muted" title="No">—</span>');
  return `
    <div class="spread" style="margin-bottom:12px">
      <div class="row"><span class="badge">${count('active')} activos</span><span class="badge amber">${count('pending')} pendientes de contraseña</span>${count('disabled') ? `<span class="badge closed">${count('disabled')} de baja</span>` : ''}</div>
      <a class="btn secondary small" href="/api/admin/players.csv" download>Exportar a Excel (CSV)</a>
    </div>
    ${sel ? adminPlayerDetail(sel) : ''}
    <div class="row" style="margin-bottom:10px"><input type="search" placeholder="Buscar por nombre, email o licencia…" data-filter="players" style="flex:1;min-width:200px">
      <select data-filter-status="players" style="width:auto"><option value="">Todos</option><option value="pending">Pendientes</option><option value="active">Activos</option><option value="disabled">Baja</option></select></div>
    <div class="tablewrap"><table id="players-table"><thead><tr><th></th><th>Jugador</th><th>Teléfono</th><th>Licencia</th><th class="c">Hcp</th><th class="c">Talla</th><th>Instagram</th><th class="c" title="Notificaciones">🔔</th><th class="c" title="Uso de imagen">📷</th><th>Estado</th><th>Inscrito</th></tr></thead><tbody>
      ${players.map((p) => `<tr class="link ${p.id === S.adminPlayer ? 'sel' : ''}" data-act="adminplayer" data-id="${p.id}" data-status="${p.status}"
        data-search="${esc(`${p.name} ${p.email} ${p.licence || ''}`.toLowerCase())}">
        <td>${avatar(p.id, p.name, p.has_photo)}</td><td><b>${esc(p.name)}</b><br><span class="small muted">${esc(p.email)}</span></td>
        <td class="small">${esc(p.phone)}</td><td class="small">${esc(p.licence || '')}</td><td class="c">${hcp(p.handicap)}</td><td class="c">${esc(p.shirt_size)}</td>
        <td class="small">${p.instagram ? `@${esc(p.instagram)}` : ''}</td><td class="c">${yes(p.consent_notifications)}</td><td class="c">${yes(p.consent_image)}</td>
        <td><span class="badge ${PSTATUS[p.status][1]}">${PSTATUS[p.status][0]}</span></td><td class="small">${fmtDateTime(p.created_at)}</td></tr>`).join('')}
    </tbody></table></div>
    ${players.length ? '' : '<p class="empty">Todavía no hay inscripciones.</p>'}`;
}

function adminPlayerDetail(p) {
  const age = ageOf(p.birth_date);
  return `<form class="card flat" data-form="adminplayer" data-id="${p.id}" style="margin-bottom:16px;border-color:var(--green-200);background:var(--green-50)" novalidate>
    <div class="spread" style="align-items:flex-start">
      <div class="row" style="gap:16px">${avatar(p.id, p.name, p.has_photo, 'xl')}
        <div><h2 style="margin:0">${esc(p.name)}</h2>
          <p class="small muted" style="margin:2px 0 6px">${age !== null ? `${age} años · ` : ''}inscrito el ${fmtDateTime(p.created_at)}${p.activated_at ? ` · activo desde ${fmtDateTime(p.activated_at)}` : ''}</p>
          <div class="row"><span class="badge ${PSTATUS[p.status][1]}">${PSTATUS[p.status][0]}</span>
            <span class="badge ${p.consent_notifications ? '' : 'closed'}">🔔 Notificaciones: ${p.consent_notifications ? 'sí' : 'no'}</span>
            <span class="badge ${p.consent_image ? '' : 'closed'}">📷 Imagen: ${p.consent_image ? 'sí' : 'no'}</span></div>
          ${p.has_photo ? `<a class="small" href="/api/photos/${p.id}?download=1">Descargar foto</a>` : ''}
          ${p.guardian_name ? `<p class="small" style="margin:6px 0 0">Tutor: <b>${esc(p.guardian_name)}</b> (${esc(p.guardian_email)})</p>` : ''}</div></div>
      <button type="button" class="btn secondary small" data-act="adminplayer" data-id="">Cerrar</button>
    </div>
    <div class="fgrid" style="margin-top:14px">
      ${field('first_name', 'Nombre', `<input id="f-first_name" name="first_name" value="${esc(p.first_name)}">`)}
      ${field('last_name', 'Apellidos', `<input id="f-last_name" name="last_name" value="${esc(p.last_name)}">`)}
      ${field('email', 'Email', `<input id="f-email" name="email" type="email" value="${esc(p.email)}">`)}
      ${field('phone', 'Teléfono', `<input id="f-phone" name="phone" value="${esc(p.phone)}">`)}
      ${field('licence', 'Licencia', `<input id="f-licence" name="licence" value="${esc(p.licence || '')}">`)}
      ${field('birth_date', 'Fecha de nacimiento', `<input id="f-birth_date" name="birth_date" type="date" value="${esc(p.birth_date || '')}">`)}
      ${field('handicap', 'Hándicap', `<input id="f-handicap" name="handicap" value="${hcp(p.handicap)}" inputmode="decimal">`)}
      ${field('shirt_size', 'Talla de polo', `<select id="f-shirt_size" name="shirt_size">${SHIRT_SIZES.map((s) => `<option ${s === p.shirt_size ? 'selected' : ''}>${s}</option>`).join('')}</select>`)}
      ${field('instagram', 'Instagram', `<input id="f-instagram" name="instagram" value="${esc(p.instagram)}">`)}
      ${field('status', 'Estado', `<select id="f-status" name="status">${Object.entries(PSTATUS).map(([k, [l]]) => `<option value="${k}" ${k === p.status ? 'selected' : ''}>${l}</option>`).join('')}</select>`)}
    </div>
    <div class="row"><button class="btn">Guardar cambios</button>
      ${p.status !== 'disabled' ? `<button type="button" class="btn secondary" data-act="invite" data-id="${p.id}">${p.status === 'pending' ? 'Reenviar correo de bienvenida' : 'Enviar enlace de contraseña'}</button>` : ''}
      <button type="button" class="btn danger" data-act="deleteplayer" data-id="${p.id}" data-name="${esc(p.name)}" style="margin-left:auto">Eliminar jugador y sus datos</button></div>
  </form>`;
}
ACT.adminplayer = (el) => { S.adminPlayer = Number(el.dataset.id) || null; render(); if (S.adminPlayer) window.scrollTo(0, 0); };
FORM.adminplayer = async (fd, form) => {
  try { await api(`/admin/players/${form.dataset.id}`, { method: 'PUT', body: Object.fromEntries(fd) }); toast('Jugador actualizado'); render(true); }
  catch (e) { toast(e.message, true); showFieldErrors(form, e.fields); }
};
ACT.invite = async (el) => {
  el.disabled = true;
  try { await api(`/admin/players/${el.dataset.id}/invite`, { method: 'POST', body: {} }); toast('Correo enviado'); } catch (e) { toast(e.message, true); }
  el.disabled = false;
};
ACT.deleteplayer = async (el) => {
  if (!confirm(`¿Eliminar a ${el.dataset.name}?\n\nSe borrarán de forma permanente sus datos, su foto, sus consentimientos, sus inscripciones y sus tarjetas. No se puede deshacer.`)) return;
  try { await api(`/admin/players/${el.dataset.id}`, { method: 'DELETE' }); S.adminPlayer = null; toast('Jugador eliminado'); render(); } catch (e) { toast(e.message, true); }
};

function filterPlayers() {
  const qv = (app.querySelector('[data-filter="players"]')?.value || '').trim().toLowerCase();
  const st = app.querySelector('[data-filter-status="players"]')?.value || '';
  app.querySelectorAll('#players-table tbody tr').forEach((tr) => {
    tr.classList.toggle('hidden', (qv && !tr.dataset.search.includes(qv)) || (st && tr.dataset.status !== st));
  });
}
document.addEventListener('input', (e) => { if (e.target.matches('[data-filter="players"]')) filterPlayers(); });
document.addEventListener('change', (e) => { if (e.target.matches('[data-filter-status="players"]')) filterPlayers(); });

async function adminRounds(rounds, players) {
  const rid = S.adminRound || (rounds.find((r) => r.status === 'live') || rounds.find((r) => r.status === 'scheduled') || rounds[0]).id;
  const d = await api(`/rounds/${rid}`);
  const r = d.round;
  const entered = new Set(d.entries.map((e) => e.id));
  return `
    <div class="row" style="margin-bottom:14px">${rounds.map((x) => `<button class="btn small ${x.id === rid ? '' : 'secondary'}" data-act="adminround" data-id="${x.id}">J${x.number}${x.status === 'live' ? ' ●' : ''}</button>`).join('')}</div>
    <div class="grid grid-2">
      <form class="card flat" data-form="round" data-id="${r.id}">
        <h3>Jornada ${r.number}</h3>
        <div class="fgrid">
          <div class="field"><label>Fecha</label><input type="date" name="date" value="${esc(r.date)}"></div>
          <div class="field"><label>Primera salida</label><input type="time" name="first_tee" value="${esc(r.first_tee)}"></div>
          <div class="field"><label>Recorrido</label><select name="nine"><option value="front" ${r.nine === 'front' ? 'selected' : ''}>Hoyos 1–9</option><option value="back" ${r.nine === 'back' ? 'selected' : ''}>Hoyos 10–18</option></select></div>
          <div class="field"><label>Estado</label><select name="status">${Object.entries(STATUS).map(([k, [l]]) => `<option value="${k}" ${k === r.status ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
        </div>
        <div class="field"><label>Notas</label><input name="notes" value="${esc(r.notes)}"></div>
        <button class="btn">Guardar jornada</button>
      </form>
      <form class="card flat" data-form="groups" data-id="${r.id}">
        <h3>Partidas y tees de salida</h3>
        <div class="fgrid">
          <div class="field"><label>Tipo de salida</label><select name="mode"><option value="tee">Escalonada por el primer hoyo</option><option value="shotgun">A tiro (cada partida en un hoyo)</option></select></div>
          <div class="field"><label>Intervalo (min)</label><input type="number" name="interval" value="10" min="5" max="20"></div>
          <div class="field"><label>Jugadores por partida</label><select name="size"><option>4</option><option>3</option><option>2</option></select></div>
          <div class="field"><label>Orden</label><select name="order"><option value="random">Sorteo</option><option value="handicap">Por hándicap</option></select></div>
        </div>
        <button class="btn" ${r.status === 'closed' ? 'disabled' : ''}>${d.groups.length ? 'Rehacer partidas' : 'Generar partidas'} (${d.entries.length} inscritos)</button>
      </form>
    </div>
    <div class="grid grid-2" style="margin-top:16px">
      <div class="card flat"><h3>Inscritos</h3>
        ${players.map((p) => `<label class="row" style="padding:4px 0"><input type="checkbox" data-act-change="adminentry" data-r="${r.id}" data-u="${p.id}" ${entered.has(p.id) ? 'checked' : ''}> ${esc(p.name)} <span class="small muted">${hcp(p.handicap)}</span></label>`).join('') || '<p class="muted">No hay jugadores activos.</p>'}
      </div>
      <div class="card flat"><h3>Tarjetas</h3>
        ${d.groups.length ? d.groups.map((g) => `<p style="margin:8px 0 2px"><b>Partida ${g.number}</b> <span class="small muted">tee ${g.start_hole} · ${esc(g.tee_time)}</span></p>
          ${g.players.map((p) => `<div class="spread small" style="padding:3px 0"><a href="#/tarjeta/${p.card_id}">${esc(p.name)}</a><span>${p.status === 'validated' ? '✓ validada' : p.status === 'playing' ? 'en juego' : 'pendiente'}</span></div>`).join('')}`).join('')
        : '<p class="muted">Sin partidas generadas.</p>'}
      </div>
    </div>`;
}
ACT.adminround = (el) => { S.adminRound = Number(el.dataset.id); render(true); };
FORM.round = async (fd, form) => { try { await api(`/admin/rounds/${form.dataset.id}`, { method: 'PUT', body: Object.fromEntries(fd) }); toast('Jornada guardada'); await refreshMe(); render(true); } catch (e) { toast(e.message, true); } };
FORM.groups = async (fd, form) => {
  if (!confirm('Se crearán las partidas, tees y marcadores para todos los inscritos. ¿Continuar?')) return;
  try { await api(`/admin/rounds/${form.dataset.id}/groups`, { method: 'POST', body: Object.fromEntries(fd) }); toast('Partidas generadas'); render(true); } catch (e) { toast(e.message, true); }
};
FORM.course = async (fd) => {
  const holes = Array.from({ length: 18 }, (_, i) => ({ hole: i + 1, par: fd.get(`par${i + 1}`), si: fd.get(`si${i + 1}`), meters: fd.get(`m${i + 1}`) }));
  try { await api('/admin/course', { method: 'PUT', body: { holes } }); toast('Campo guardado'); } catch (e) { toast(e.message, true); }
};
FORM.settings = async (fd, form) => {
  const body = Object.fromEntries(fd);
  body.feature_live = form.feature_live.checked; body.feature_shop = form.feature_shop.checked;
  try { await api('/admin/settings', { method: 'PUT', body }); await refreshMe(); toast('Ajustes guardados'); render(true); } catch (e) { toast(e.message, true); }
};
const rowData = (id) => { const tr = app.querySelector(`tr[data-row="${id}"]`); return Object.fromEntries([...tr.querySelectorAll('[name]')].map((i) => [i.name, i.type === 'checkbox' ? i.checked : i.value])); };
ACT.saveproduct = async (el) => {
  const d = rowData(el.dataset.id);
  try { await api(`/admin/products/${el.dataset.id}`, { method: 'PUT', body: { name: d.name, price_cents: Math.round(Number(d.price) * 100), stock: Number(d.stock), active: d.active } }); toast('Producto actualizado'); } catch (e) { toast(e.message, true); }
};
CHANGE.orderstatus = async (el) => { try { await api(`/admin/orders/${el.dataset.id}`, { method: 'PUT', body: { status: el.value } }); toast('Pedido actualizado'); } catch (e) { toast(e.message, true); } };
CHANGE.adminentry = async (el) => { try { await api(`/admin/rounds/${el.dataset.r}/entries`, { method: 'POST', body: { user_id: Number(el.dataset.u), on: el.checked } }); render(true); } catch (e) { toast(e.message, true); } };

// ---------- Arranque ----------

document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (!el || el.disabled || el.tagName === 'A') return;
  e.preventDefault();
  ACT[el.dataset.act]?.(el, e);
});
document.addEventListener('change', (e) => { const el = e.target.closest('[data-act-change]'); if (el) CHANGE[el.dataset.actChange]?.(el); });
document.addEventListener('submit', (e) => {
  const form = e.target.closest('[data-form]');
  if (!form) return;
  e.preventDefault();
  FORM[form.dataset.form]?.(new FormData(form), form, e.submitter);
});
window.addEventListener('hashchange', () => render());

async function refreshMe() {
  const [me, rd] = await Promise.all([api('/me'), api('/rounds')]);
  S.me = me.user; S.hasPhoto = me.has_photo; S.settings = me.settings;
  S.liveAny = rd.rounds.some((r) => r.status === 'live');
}

// Tiempo real con plan B: si el hosting retiene los eventos, las vistas en directo se refrescan cada 15 s.
let sseTimer;
let lastStreamMsg = 0;
function connectStream() {
  const es = new EventSource('/api/stream');
  es.onmessage = (ev) => {
    lastStreamMsg = Date.now();
    const msg = JSON.parse(ev.data);
    if (msg.type === 'ping' || !current.live || !S.me) return;
    if (document.activeElement && ['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;
    clearTimeout(sseTimer);
    sseTimer = setTimeout(() => render(true), 250);
  };
}
setInterval(() => {
  if (!current.live || !S.me || document.visibilityState !== 'visible' || Date.now() - lastStreamMsg < 45000) return;
  if (document.activeElement && ['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;
  render(true);
}, 15000);

refreshMe().catch(() => {}).finally(() => { render(); connectStream(); });
