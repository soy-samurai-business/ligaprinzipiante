-- Liga de Golf Baviera — esquema MySQL (MySQL 8 / MariaDB 10.4+)
-- La aplicación crea estas tablas automáticamente al arrancar si no existen.
-- También puede importarse a mano desde phpMyAdmin (pestaña «Importar»).

CREATE TABLE IF NOT EXISTS settings (
  setting_key   VARCHAR(64) NOT NULL PRIMARY KEY,
  setting_value TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  email          VARCHAR(190) NOT NULL,
  pass_hash      VARCHAR(200) NULL,
  first_name     VARCHAR(100) NOT NULL,
  last_name      VARCHAR(150) NOT NULL DEFAULT '',
  name           VARCHAR(255) NOT NULL,
  phone          VARCHAR(30)  NOT NULL DEFAULT '',
  licence        VARCHAR(30)  NULL,
  birth_date     DATE NULL,
  handicap       DECIMAL(4,1) NOT NULL DEFAULT 36.0,
  shirt_size     VARCHAR(5)   NOT NULL DEFAULT '',
  instagram      VARCHAR(40)  NOT NULL DEFAULT '',
  bio            VARCHAR(500) NOT NULL DEFAULT '',
  role           ENUM('player','admin') NOT NULL DEFAULT 'player',
  status         ENUM('pending','active','disabled') NOT NULL DEFAULT 'pending',
  consent_notifications TINYINT(1) NOT NULL DEFAULT 0,
  consent_image  TINYINT(1) NOT NULL DEFAULT 0,
  guardian_name  VARCHAR(200) NULL,
  guardian_email VARCHAR(190) NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  activated_at   DATETIME NULL,
  UNIQUE KEY uq_users_email (email),
  UNIQUE KEY uq_users_licence (licence)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS photos (
  user_id    INT UNSIGNED NOT NULL PRIMARY KEY,
  mime       VARCHAR(30) NOT NULL,
  data       MEDIUMBLOB NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_photos_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Registro inmutable de consentimientos (prueba exigida por el RGPD, art. 7.1).
CREATE TABLE IF NOT EXISTS consents (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id      INT UNSIGNED NOT NULL,
  consent      ENUM('privacy','notifications','image','guardian') NOT NULL,
  granted      TINYINT(1) NOT NULL,
  text_version VARCHAR(20) NOT NULL,
  ip           VARCHAR(64) NOT NULL DEFAULT '',
  user_agent   VARCHAR(255) NOT NULL DEFAULT '',
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY ix_consents_user (user_id),
  CONSTRAINT fk_consents_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sessions (
  token      CHAR(48) NOT NULL PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  expires_at BIGINT NOT NULL,
  KEY ix_sessions_user (user_id),
  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Enlaces de un solo uso enviados por correo (crear contraseña / recuperarla). Se guarda solo el hash.
CREATE TABLE IF NOT EXISTS auth_tokens (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  purpose    ENUM('activate','reset') NOT NULL,
  expires_at DATETIME NOT NULL,
  used_at    DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_tokens_hash (token_hash),
  CONSTRAINT fk_tokens_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS course_holes (
  hole   TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  par    TINYINT UNSIGNED NOT NULL,
  si     TINYINT UNSIGNED NOT NULL,
  meters SMALLINT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rounds (
  id        INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  number    TINYINT UNSIGNED NOT NULL,
  date      DATE NOT NULL,
  nine      ENUM('front','back') NOT NULL DEFAULT 'front',
  first_tee CHAR(5) NOT NULL DEFAULT '09:00',
  status    ENUM('scheduled','live','closed') NOT NULL DEFAULT 'scheduled',
  notes     VARCHAR(500) NOT NULL DEFAULT '',
  UNIQUE KEY uq_rounds_number (number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS entries (
  round_id   INT UNSIGNED NOT NULL,
  user_id    INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (round_id, user_id),
  CONSTRAINT fk_entries_round FOREIGN KEY (round_id) REFERENCES rounds (id) ON DELETE CASCADE,
  CONSTRAINT fk_entries_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Partidas de cada jornada ("groups" es palabra reservada en MySQL 8).
CREATE TABLE IF NOT EXISTS tee_groups (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  round_id    INT UNSIGNED NOT NULL,
  number      TINYINT UNSIGNED NOT NULL,
  start_hole  TINYINT UNSIGNED NOT NULL,
  tee_time    CHAR(5) NOT NULL,
  started_at  DATETIME NULL,
  finished_at DATETIME NULL,
  CONSTRAINT fk_groups_round FOREIGN KEY (round_id) REFERENCES rounds (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cards (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  round_id         INT UNSIGNED NOT NULL,
  user_id          INT UNSIGNED NOT NULL,
  group_id         INT UNSIGNED NULL,
  marker_id        INT UNSIGNED NULL,
  handicap         DECIMAL(4,1) NOT NULL,
  playing_hcp      SMALLINT NOT NULL,
  status           ENUM('pending','playing','validated') NOT NULL DEFAULT 'pending',
  player_signed_at DATETIME NULL,
  marker_signed_at DATETIME NULL,
  validated_at     DATETIME NULL,
  UNIQUE KEY uq_cards_round_user (round_id, user_id),
  CONSTRAINT fk_cards_round FOREIGN KEY (round_id) REFERENCES rounds (id) ON DELETE CASCADE,
  CONSTRAINT fk_cards_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_cards_group FOREIGN KEY (group_id) REFERENCES tee_groups (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS scores (
  card_id    INT UNSIGNED NOT NULL,
  hole       TINYINT UNSIGNED NOT NULL,
  strokes    TINYINT UNSIGNED NOT NULL,
  updated_by INT UNSIGNED NULL,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY (card_id, hole),
  CONSTRAINT fk_scores_card FOREIGN KEY (card_id) REFERENCES cards (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NULL,
  action     VARCHAR(50) NOT NULL,
  detail     TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS products (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  description VARCHAR(500) NOT NULL DEFAULT '',
  price_cents INT UNSIGNED NOT NULL,
  color       VARCHAR(9) NOT NULL DEFAULT '#ffffff',
  accent      VARCHAR(9) NOT NULL DEFAULT '#1f8a4c',
  sizes       VARCHAR(100) NOT NULL DEFAULT '["S","M","L","XL","XXL"]',
  stock       INT NOT NULL DEFAULT 50,
  active      TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orders (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NULL,
  status      ENUM('pendiente_pago','pagado','entregado','cancelado') NOT NULL DEFAULT 'pendiente_pago',
  total_cents INT UNSIGNED NOT NULL,
  delivery    ENUM('club','jornada') NOT NULL DEFAULT 'club',
  notes       VARCHAR(300) NOT NULL DEFAULT '',
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS order_items (
  order_id    INT UNSIGNED NOT NULL,
  product_id  INT UNSIGNED NOT NULL,
  name        VARCHAR(150) NOT NULL,
  size        VARCHAR(5) NOT NULL,
  qty         SMALLINT UNSIGNED NOT NULL,
  price_cents INT UNSIGNED NOT NULL,
  KEY ix_items_order (order_id),
  CONSTRAINT fk_items_order FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
